<?php
/**
 * Plugin Name:       Enpix Core
 * Plugin URI:        https://themes.themexplosion.com/enpix/
 * Description:       This plugin adds the core features to the Enpix WordPress theme. You must have to install this plugin to get all the features included with the Enpix theme.
 * Version:           1.0.0
 * Requires PHP:      7.4
 * Author:            Themexplosion
 * Author URI:        https://themeforest.net/user/themexplosion
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       enpix-core
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit();

final class Enpix_core {
	const MINIMUM_ELEMENTOR_VERSION = '3.7.0';
	const  MINIMUM_PHP_VERSION      = '7.4';

	private function __construct() {
		$this->define_constants();
		$this->plugin_includes();
		$this->init_hooks();
	}

	/**
	 * Initializing the class
	 *
	 * @return \Enpix_core
	 */
	public static function init() {
		static $instance = false;

		if ( ! $instance ) {
			$instance = new self();
		}

		return $instance;
	}

	/**
	 * Define necessary constants to use plugin wide
	 *
	 * @return void
	 */
	public function define_constants() {
		define( 'ENPIX_CORE_FILE', __FILE__ );
		define( 'ENPIX_CORE_DIR', __DIR__ );
		define( 'ENPIX_CORE_VERSION', '1.0.0' );
		define( 'ENPIX_CORE_URL', plugins_url( '', ENPIX_CORE_FILE ) );
		define( 'ENPIX_CORE_ASSETS', ENPIX_CORE_URL . '/assets/' );
		define( 'ENPIX_CORE_CSS', ENPIX_CORE_URL . '/assets/css/' );
		define( 'ENPIX_CORE_IMG', ENPIX_CORE_URL . '/assets/img/' );
		define( 'WID_IMG', ENPIX_CORE_URL . '/widgets/images/' );
	}


	/**
	 * Include necessary files for the plugin
	 *
	 * @return void
	 */
	public function plugin_includes() {
		// Plugin custom functions.
		require_once ENPIX_CORE_DIR . '/inc/core_functions.php';

		require_once ENPIX_CORE_DIR . '/cpt/cpt-projects.php';
		require_once ENPIX_CORE_DIR . '/cpt/cpt-team.php';
		require_once ENPIX_CORE_DIR . '/wp-widgets/widgets.php';

		require_once ENPIX_CORE_DIR . '/csf/csf.php';
		require_once ENPIX_CORE_DIR . '/inc/options/admin-options.php';
		require_once ENPIX_CORE_DIR . '/inc/options/metabox-config.php';
		require_once ENPIX_CORE_DIR . '/inc/options/profile-option.php';
	}

	/**
	 * Initialize hooks and related functions
	 *
	 * @return void
	 */
	public function init_hooks() {
		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'enpix_core_plugin_config' ] );
		add_action( 'after_setup_theme', [ $this, 'hide_admin_bar' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enpix_admin_style' ], 11 );
	}

	/**
	 * Function to load textdomain for internationalization
	 *
	 * @return void
	 */
	public function i18n() {
		load_plugin_textdomain( 'enpix-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Hide admin bar for non admins
	 *
	 * @return void
	 */
	public function hide_admin_bar() {
		if ( is_user_logged_in() ) {
			$user               = wp_get_current_user();
			$current_user_roles = $user->roles;
			$is_matching        = array_intersect( $current_user_roles, [ 'subscriber' ] );
			if ( ! empty( $is_matching ) ) {
				add_filter( 'show_admin_bar', '__return_false' );
			}
		}
	}

	/**
	 * Admin notice for minimum php version
	 *
	 * @return void
	 */
	public function admin_notice_minimum_php_version() {
		$message = sprintf(
		/* translators: 1: Enpix Core 2: PHP */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'enpix-core' ),
			'<strong>' . esc_html__( 'Enpix Core', 'enpix-core' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'enpix-core' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice for elementor version
	 *
	 * @return void
	 */
	public function admin_notice_minimum_elementor_version() {
		/* translators: 1: Enpix Core 2: Elementor */
		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'enpix-core' ),
			'<strong>' . esc_html__( 'Enpix Core', 'enpix-core' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'enpix-core' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice if dependency plugin is not found
	 *
	 * @return void
	 */
	public function admin_notice_missing_main_plugin() {
		$message = sprintf(
		/* translators: 1: Enpix Core 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'enpix-core' ),
			'<strong>' . esc_html__( 'Enpix Core', 'enpix-core' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'enpix-core' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Checking if system requirements
	 *
	 * @return void
	 */
	public function enpix_core_plugin_config() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );

			return;
		}

		// Check for required Elementor version.
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );

			return;
		}

		// Check for required PHP version.
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );

			return;
		}

		// Add new Elementor Categories.
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_widget_category' ] );

		// Register Widget Scripts.
		// add_action( 'elementor/frontend/before_register_scripts', [ $this, 'register_widget_scripts' ] );
		// add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_widget_scripts' ] );
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'register_widget_scripts' ] );
		// add_action( 'wp_enqueue_scripts', [ $this, 'enpix_core_plugin_scripts' ] );

		// Register Widget Scripts.
		// add_action( 'elementor/editor/before_enqueue_scripts', array( $this, 'enqueue_elementor_editor_styles' ) );
		// add_action( 'elementor/frontend/after_enqueue_styles', array( $this, 'enqueue_widget_styles' ) );

		// Register New Widgets.
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
	}

	/**
	 * Add a function to register widget scripts
	 *
	 * @return void
	 */
	public function register_widget_scripts() {
		wp_enqueue_style( 'enpix-admin', ENPIX_CORE_CSS . 'elementor-editor.css' );
	}

	public function enpix_admin_style() {
		wp_enqueue_style( 'enpix-admin', ENPIX_CORE_CSS . 'admin.css' );
	}

	/**
	 * Add Elementor widget category
	 *
	 * @return void
	 */
	public function add_widget_category( $elements_manager ) {
		$elements_manager->add_category(
			'enpix',
			[
				'title' => esc_html__( 'Enpix', 'enpix-core' ),
				'icon'  => 'fa fa-plug',
			]
		);
	}

	/**
	 * Include the files necessary for this plugin
	 *
	 * @return void
	 */
	public function enpix_core_plugin_scripts() {

	}

	/**
	 * Register custom Elementor Widgets
	 *
	 * @return void
	 */
	public function register_widgets() {
		$widgets = [
			'Hero',
			'Team',
			'Testimonials',
			'Post',
			'Projects',
			'Services',
			'Logo_Showcase',
		];

		foreach ( $widgets as $widget ) {
			include ENPIX_CORE_DIR . "/widgets/{$widget}.php";
			$widget_class = "Enpix\\Core\\$widget";
			\Elementor\Plugin::instance()->widgets_manager->register( new $widget_class() );
		}
	}
}

/**
 * Function to initialize Enpix Core plugin
 *
 * @return \Enpix_core
 */
function enpix_core_plugin() {
	return Enpix_core::init();
}

// Kick off the plugin.
enpix_core_plugin();
