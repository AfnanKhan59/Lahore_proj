<?php
defined( 'ABSPATH' ) || exit();

/**
 * Elementor URL field output
 *
 * @param $settings_key
 * @param bool         $echo
 *
 * @return string
 */
function enpix_el_btn( $settings_key, $echo = true ) {
	if ( $echo ) {
		echo $settings_key['is_external'] == true ? 'target="_blank"' : '';
		echo $settings_key['nofollow'] == true ? 'rel="nofollow"' : '';
		echo ! empty( $settings_key['url'] ) ? 'href="' . esc_url( $settings_key['url'] ) . '"' : '';
	} else {
		$output  = $settings_key['is_external'] == true ? 'target="_blank"' : '';
		$output .= $settings_key['nofollow'] == true ? 'rel="nofollow"' : '';
		$output .= ! empty( $settings_key['url'] ) ? 'href="' . esc_url( $settings_key['url'] ) . '"' : '';

		return $output;
	}
}

// Icon Array.
function enpix_icon_array( $k, $replace = 'icon', $separator = '-' ) {
	$v = [];
	foreach ( $k as $kv ) {
		$kv  = str_replace( $separator, ' ', $kv );
		$kv  = str_replace( $replace, '', $kv );
		$v[] = array_push( $v, ucwords( $kv ) );
	}
	foreach ( $v as $key => $value ) {
		if ( $key & 1 ) {
			unset( $v[ $key ] );
		}
	}

	return array_combine( $k, $v );
}

/**
 * Sharing on social media
 *
 * @return void
 */
function enpix_social_share() {
	?>
		<div class="share-buttons">
			<p><?php esc_html_e( 'Share: ', 'enpix-core' ); ?></p>
			<div>
				<a target="_blank" href="https://facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fa-brands fa-facebook"></i></a>
				<a target="_blank" href="https://twitter.com/intent/tweet?text=<?php the_permalink(); ?>"><i class="fa-brands fa-twitter"></i></a>
				<a target="_blank" href="https://www.pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>"><i class="fa-brands fa-pinterest-p"></i></a>
				<a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>"><i class="fa-brands fa-linkedin-in"></i></a>
			</div>
		</div>
	<?php
}

add_action( 'enpix_social_share', 'enpix_social_share' );

/**
 * Elementor Title tags
 *
 * @return array h1-h6 heading tags, div ,span and p
 */
function enpix_el_title_tags() {
	return [
		'h1'   => __( 'H1', 'enpix-core' ),
		'h2'   => __( 'H2', 'enpix-core' ),
		'h3'   => __( 'H3', 'enpix-core' ),
		'h4'   => __( 'H4', 'enpix-core' ),
		'h5'   => __( 'H5', 'enpix-core' ),
		'h6'   => __( 'H6', 'enpix-core' ),
		'div'  => __( 'Div', 'enpix-core' ),
		'span' => __( 'Span', 'enpix-core' ),
		'p'    => __( 'Paragraph', 'enpix-core' ),
	];
}

/**
 * Get Default Image Elementor
 *
 * @param string $settings_key $settings['image_key'] for grabbing the image
 * @param string $alt Alt text for image.
 * @param string $class Class name for the img tag.
 * @param array  $atts Other attributes if any.
 */
function enpix_el_image( $settings_key = '', $alt = '', $class = '', $atts = [] ) {
	if ( ! empty( $settings_key['id'] ) ) {
		echo wp_get_attachment_image( $settings_key['id'], 'full', '', [ 'class' => $class ] );
	} elseif ( ! empty( $settings_key['url'] ) && empty( $settings_key['id'] ) ) {
		$class = ! empty( $class ) ? "class='$class'" : '';
		$attss = '';

		if ( ! empty( $atts ) ) {
			foreach ( $atts as $k => $att ) {
				$attss .= "$k=" . "'$att'";
			}
		}
		echo "<img src='{$settings_key['url']}' $class alt='$alt' $attss>";
	}
}

/**
 * Pages or Post Array
 *
 * @param string $post_type
 * @param int    $parent
 *
 * @return array Some posts or pages
 *
 * @since 1.0.0
 */
function enpix_get_posts( $post_type = 'post', $parent = 0 ) {
	$posts       = get_pages(
		[
			'post_type' => $post_type,
			'parent'    => $parent,
		]
	);
	$posts_array = [];
	if ( $posts ) {
		foreach ( $posts as $post ) {
			$posts_array [ $post->ID ] = $post->post_title;
		}
	}

	return $posts_array;
}

/**
 * @param string $post_type
 * @param int    $limit
 * @param string $search
 *
 * @return array
 */
function enpix_get_query_post_list( $post_type = 'any', $limit = - 1, $search = '' ) {
	global $wpdb;
	$where = '';
	$data  = [];

	if ( - 1 == $limit ) {
		$limit = '';
	} elseif ( 0 == $limit ) {
		$limit = 'limit 0,1';
	} else {
		$limit = $wpdb->prepare( ' limit 0,%d', esc_sql( $limit ) );
	}

	if ( 'any' === $post_type ) {
		$in_search_post_types = get_post_types( [ 'exclude_from_search' => false ] );
		if ( empty( $in_search_post_types ) ) {
			$where .= ' AND 1=0 ';
		} else {
			$where .= " AND {$wpdb->posts}.post_type IN ('" . join(
				"', '",
				array_map( 'esc_sql', $in_search_post_types )
			) . "')";
		}
	} elseif ( ! empty( $post_type ) ) {
		$where .= $wpdb->prepare( " AND {$wpdb->posts}.post_type = %s", esc_sql( $post_type ) );
	}

	if ( ! empty( $search ) ) {
		$where .= $wpdb->prepare( " AND {$wpdb->posts}.post_title LIKE %s", '%' . esc_sql( $search ) . '%' );
	}

	$query   = "select post_title,ID  from $wpdb->posts where post_status = 'publish' $where $limit";
	$results = $wpdb->get_results( $query );
	if ( ! empty( $results ) ) {
		foreach ( $results as $row ) {
			$data[ $row->ID ] = $row->post_title;
		}
	}

	return $data;
}

/**
 * Get all elementor page templates
 *
 * @param null $type
 *
 * @return array
 */
function enpix_get_el_templates( $type = null ) {
	$options = [];

	if ( $type ) {
		$args              = [
			'post_type'      => 'elementor_library',
			'posts_per_page' => - 1,
		];
		$args['tax_query'] = [
			[
				'taxonomy' => 'elementor_library_type',
				'field'    => 'slug',
				'terms'    => $type,
			],
		];

		$page_templates = get_posts( $args );

		if ( ! empty( $page_templates ) && ! is_wp_error( $page_templates ) ) {
			foreach ( $page_templates as $post ) {
				$options[ $post->ID ] = $post->post_title;
			}
		}
	} else {
		$options = enpix_get_query_post_list( 'elementor_library' );
	}

	return $options;
}

/**
 * Post order order by
 */
function enpix_order_by() {
	$orderby = [
		'none'          => esc_html__( 'None', 'enpix-core' ),
		'author'        => esc_html__( 'Author', 'enpix-core' ),
		'title'         => esc_html__( 'Title', 'enpix-core' ),
		'date'          => esc_html__( 'Date', 'enpix-core' ),
		'rand'          => esc_html__( 'Random', 'enpix-core' ),
		'comment_count' => esc_html__( 'Comment Count', 'enpix-core' ),
		'menu_order'    => esc_html__( 'Menu Order', 'enpix-core' ),
	];

	return $orderby;
}

add_filter(
	'upload_mimes',
	function ( $mimes ) {
		$mimes['svg'] = 'image/svg+xml';

		return $mimes;
	}
);


