<?php
defined( 'ABSPATH' ) || exit();

// Video Post Meta.
include 'metaboxes/video-meta.php';
include 'metaboxes/page-options.php';
include 'metaboxes/team-meta.php';
include 'metaboxes/project-meta.php';
