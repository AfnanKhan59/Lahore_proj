<?php
defined( 'ABSPATH' ) || die;

// Admin option unique id.
$prefix = 'enpix_opt';

// Enpix Admin Options.
CSF::createOptions(
	$prefix,
	[
		'menu_title'          => esc_html__( 'Enpix Options', 'enpix-core' ),
		'menu_slug'           => 'enpix-options',
		'framework_title'     => esc_html__( 'Enpix Options', 'enpix-core' ),
		'framework_class'     => 'themx-options',
		'footer_text'         => esc_html__( 'Copyright Themexplosion @2022', 'enpix-core' ),
		'footer_credit'       => esc_html__( 'Thanks from enpix Team.', 'enpix-core' ),
		'theme'               => 'light',
		'menu_icon'           => 'dashicons-shield',
		'admin_bar_menu_icon' => 'dashicons-shield',
		'menu_position'       => 3,
		'show_in_customizer'  => true,
	]
);

// General Admin Options.
CSF::createSection(
	$prefix,
	[
		'id'    => 'general',
		'title' => esc_html__( 'General', 'enpix-core' ),
		'icon'  => 'fas fa-cog',
	]
);

// Preloader Options.
CSF::createSection(
	$prefix,
	[
		'parent' => 'general',
		'title'  => esc_html__( 'Preloader', 'enpix-core' ),
		'fields' => [
			[
				'id'         => 'is_preloader',
				'title'      => esc_html__( 'Preloader Visibility', 'enpix-core' ),
				'type'       => 'switcher',
				'text_on'    => esc_html__( 'Enable', 'enpix-core' ),
				'text_off'   => esc_html__( 'Disable', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,
			],

			[
				'id'         => 'preloader_text',
				'title'      => esc_html__( 'Pre-loader Text', 'enpix-core' ),
				'type'       => 'text',
				'default'    => esc_html__( 'ENPIX', 'enpix-core' ),
				'dependency' => [ 'is_preloader', '==', 'true' ],
			],

			[
				'id'         => 'preloader_color',
				'type'       => 'fieldset',
				'title'      => esc_html__( 'Preloader Color', 'enpix-core' ),
				'dependency' => [ 'is_preloader', '==', 'true' ],
				'fields'     => [
					[
						'title'       => esc_html__( 'Text Color', 'enpix-core' ),
						'id'          => 'preloader_text_color',
						'type'        => 'color',
						'output'      => '.ctn-preloader .animation-preloader .txt-loading .letters-loading:before',
						'default'     => '#FF6701',
						'output_mode' => 'color',
					],

					[
						'title'   => esc_html__( 'Spinner Color', 'enpix-core' ),
						'id'      => 'preloader_spinner_color',
						'type'    => 'color',
						'default' => '#212833',
						'output'  => [
							'border-top-color'    => '.ctn-preloader .animation-preloader .spinner',
							'border-bottom-color' => '.ctn-preloader .animation-preloader .spinner',
						],
					],
				],
			],

			[
				'id'      => 'scroll_bg_color',
				'type'    => 'color',
				'title'   => esc_html__( 'Scroll to Top Link Background', 'enpix-core' ),
				'default' => '#ffffff',
				'output'  => [
					'background' => 'header.scroll',
				],
			],
		],
	]
);

// Back to top button
CSF::createSection(
	$prefix,
	[
		'parent' => 'general',
		'title'  => esc_html__( 'Back To Top', 'enpix-core' ),
		'fields' => [
			[
				'id'         => 'is_btt',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Back To Top Visibility', 'enpix-core' ),
				'text_on'    => esc_html__( 'Show', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,

			],

			[
				'id'         => 'btt_icon',
				'type'       => 'icon',
				'title'      => esc_html__( 'Icon', 'enpix-core' ),
				'default'    => 'fas fa-angle-up',
				'dependency' => [ 'is_btt', '==', 'true' ],
			],

			[
				'id'         => 'btt_color',
				'type'       => 'tabbed',
				'title'      => esc_html__( 'Back To Top Button Color', 'enpix-core' ),
				'dependency' => [ 'is_btt', '==', 'true' ],
				'tabs'       => [
					[
						'title'  => esc_html__( 'Normal Color', 'enpix-core' ),
						'fields' => [
							[
								'id'      => 'icon_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Icon Color', 'enpix-core' ),
								'default' => '#ffffff',
								'output'  => '#back2top',
							],

							[
								'id'          => 'bg_color',
								'type'        => 'color',
								'title'       => esc_html__( 'Background Color', 'enpix-core' ),
								'output_mode' => 'background-color',
								'output'      => '#back2top',
								'default'     => '#FF6701',
							],
						],
					],

					[
						'title'  => esc_html__( 'Hover Color', 'enpix-core' ),
						'fields' => [
							[
								'id'      => 'hover_icon_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Icon Color', 'enpix-core' ),
								'default' => '#ffffff',
								'output'  => '#back2top:hover',
							],

							[
								'id'          => 'hover_bg_color',
								'type'        => 'color',
								'title'       => esc_html__( 'Background Color', 'enpix-core' ),
								'output_mode' => 'background-color',
								'default'     => '#212833',
								'output'      => '#back2top:hover',
							],
						],
					],
				],
			],
		],
	]
);

// Color Schemes
CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Color Schemes', 'enpix-core' ),
		'icon'   => 'csf-tab-icon fas fa-tint',
		'fields' => [
			[
				'id'          => 'brand_color',
				'type'        => 'color',
				'title'       => esc_html__( 'Brand Color', 'enpix-core' ),
				'subtitle'    => esc_html__( 'Main color of the whole website.', 'enpix-core' ),
				'default'     => '#FF6701',
				'output'      => ':root',
				'output_mode' => '--enpix-brand',
			],

			[
				'id'          => 'secondary_color',
				'type'        => 'color',
				'title'       => esc_html__( 'Secondary Color', 'enpix-core' ),
				'subtitle'    => esc_html__( 'Secondary color for the whole website.', 'enpix-core' ),
				'default'     => '#212833',
				'output'      => ':root',
				'output_mode' => '--enpix-brand-secondary',
			],

			[
				'id'          => 'body_text_color',
				'type'        => 'color',
				'title'       => esc_html__( 'Body Text Color', 'enpix-core' ),
				'subtitle'    => esc_html__( 'All paragraph colors', 'enpix-core' ),
				'default'     => '#636466',
				'output'      => ':root',
				'output_mode' => '--enpix-paragraph',
			],

			[
				'id'          => 'heading_color',
				'type'        => 'color',
				'title'       => esc_html__( 'Heading Color', 'enpix-core' ),
				'subtitle'    => esc_html__( 'All Heading Colors', 'enpix-core' ),
				'default'     => '#212833',
				'output'      => ':root',
				'output_mode' => '--enpix-heading',
			],
		],
	]
);

// Header Options
CSF::createSection(
	$prefix,
	[
		'id'    => 'header',
		'title' => esc_html__( 'Header', 'enpix-core' ),
		'icon'  => 'fas fa-bars',
	]
);

// Logo
CSF::createSection(
	$prefix,
	[
		'parent' => 'header',
		'title'  => esc_html__( 'Logo', 'enpix-core' ),
		'fields' => [
			[
				'id'       => 'main_logo',
				'type'     => 'media',
				'title'    => esc_html__( 'Main Logo', 'enpix-core' ),
				'subtitle' => esc_html__( 'Select the main logo for your website', 'enpix-core' ),
			],
			[
				'id'       => 'retina_logo',
				'type'     => 'media',
				'title'    => esc_html__( 'Retina Logo', 'enpix-core' ),
				'subtitle' => esc_html__( 'Select the retina logo for your website', 'enpix-core' ),
			],
		],
	],
);

CSF::createSection(
	$prefix,
	[
		'parent' => 'header',
		'title'  => esc_html__( 'Header Settings', 'enpix-core' ),
		'fields' => [
			[
				'id'      => 'header_layout',
				'type'    => 'image_select',
				'title'   => esc_html__( 'Global Header Layout', 'enpix-core' ),
				'options' => [
					'1' => plugins_url( 'images/menu/menu-1.png', __FILE__ ),
					'2' => plugins_url( 'images/menu/menu-2.png', __FILE__ ),
				],
				'default' => '1',
			],
			[
				'id'         => 'cta_button',
				'type'       => 'fieldset',
				'title'      => esc_html__( 'Call to action button', 'enpix-core' ),
				'dependency' => [ 'header_layout', '==', '1' ],
				'fields'     => [
					[
						'id'         => 'is_cta',
						'type'       => 'switcher',
						'title'      => esc_html__( 'Show call to action button?', 'enpix-core' ),
						'text_on'    => esc_html__( 'Show', 'enpix-core' ),
						'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
						'text_width' => 80,
						'default'    => true,
					],
					[
						'id'      => 'cta_url',
						'type'    => 'link',
						'title'   => esc_html__( 'Button link', 'enpix-core' ),
						'default' => [
							'url'    => esc_url( site_url() ),
							'text'   => esc_html__( 'Get Started', 'enpix-core' ),
							'target' => '_blank',
						],
					],
					[
						'id'    => 'cta_color',
						'type'  => 'tabbed',
						'title' => esc_html__( 'Color', 'enpix-core' ),
						'tabs'  => [
							[
								'title'  => esc_html__( 'Normal', 'enpix-core' ),
								'fields' => [
									[
										'id'     => 'cta_text_normal',
										'type'   => 'color',
										'title'  => esc_html__( 'Text Color', 'enpix-core' ),
										'output' => '.enpix-cta',
									],

									[
										'id'     => 'cta_bg_normal',
										'type'   => 'color',
										'title'  => esc_html__( 'Background', 'enpix-core' ),
										'output' => '.enpix-cta',
									],

									[
										'id'     => 'cta_border_normal',
										'type'   => 'border',
										'title'  => esc_html__( 'Border', 'enpix-core' ),
										'output' => '.enpix-cta',
									],
								],
							],

							[
								'title'  => esc_html__( 'Hover', 'enpix-core' ),
								'fields' => [
									[
										'id'     => 'cta_text_hover',
										'type'   => 'color',
										'title'  => esc_html__( 'Text Color', 'enpix-core' ),
										'output' => '.enpix-cta:hover',
									],

									[
										'id'     => 'cta_bg_hover',
										'type'   => 'color',
										'title'  => esc_html__( 'Background', 'enpix-core' ),
										'output' => '.enpix-cta:hover',
									],

									[
										'id'     => 'cta_border_hover',
										'type'   => 'border',
										'title'  => esc_html__( 'Border', 'enpix-core' ),
										'output' => '.enpix-cta:hover',
									],
								],
							],
						],
					],
				],
			],
			[
				'id'         => 'header_search',
				'type'       => 'fieldset',
				'title'      => esc_html__( 'Search Form', 'enpix-core' ),
				'dependency' => [ 'header_layout', '==', '2' ],
				'fields'     => [
					[
						'id'         => 'is_header_search',
						'type'       => 'switcher',
						'title'      => esc_html__( 'Enable search feature?', 'enpix-core' ),
						'text_on'    => esc_html__( 'Yes', 'enpix-core' ),
						'text_off'   => esc_html__( 'No', 'enpix-core' ),
						'text_width' => 80,
						'default'    => true,
					],
					[
						'id'         => 'header_search_title',
						'type'       => 'text',
						'title'      => esc_html__( 'Search Title', 'enpix-core' ),
						'default'    => esc_html__( 'Looking for something?', 'enpix-core' ),
						'dependency' => [ 'is_header_search', '==', 'true' ],
					],
					[
						'id'         => 'header_search_placeholder',
						'type'       => 'text',
						'title'      => esc_html__( 'Placeholder text', 'enpix-core' ),
						'default'    => esc_html__( 'Search across the site.....', 'enpix-core' ),
						'dependency' => [ 'is_header_search', '==', 'true' ],
					],
				],
			],
			[
				'id'         => 'header_sidebar',
				'type'       => 'fieldset',
				'title'      => esc_html__( 'Floating Sidebar', 'enpix-core' ),
				'dependency' => [ 'header_layout', '==', '2' ],
				'fields'     => [
					[
						'id'         => 'is_floating_sidebar',
						'type'       => 'switcher',
						'title'      => esc_html__( 'Show floating sidebar?', 'enpix-core' ),
						'text_on'    => esc_html__( 'Yes', 'enpix-core' ),
						'text_off'   => esc_html__( 'No', 'enpix-core' ),
						'text_width' => 80,
						'default'    => true,
					],
					[
						'id'         => 'fs_description',
						'type'       => 'wp_editor',
						'title'      => esc_html__( 'Write something about your company', 'enpix-core' ),
						'dependency' => [ 'is_floating_sidebar', '==', 'true' ],
					],
					[
						'id'         => 'fs_contact_info',
						'type'       => 'fieldset',
						'title'      => esc_html__( 'Contact Information', 'enpix-core' ),
						'dependency' => [ 'is_floating_sidebar', '==', 'true' ],
						'fields'     => [
							[
								'id'          => 'email',
								'type'        => 'text',
								'title'       => esc_html__( 'Email', 'enpix-core' ),
								'placeholder' => 'info@example.com',
							],
							[
								'id'          => 'phone',
								'type'        => 'text',
								'title'       => esc_html__( 'Phone', 'enpix-core' ),
								'placeholder' => '+1 234 567 8901',
							],
						],
					],
					[
						'id'         => 'fs_socials',
						'type'       => 'group',
						'title'      => esc_html__( 'Social Platforms', 'enpix-core' ),
						'dependency' => [ 'is_floating_sidebar', '==', 'true' ],
						'fields'     => [
							[
								'id'    => 'social_name',
								'type'  => 'text',
								'title' => esc_html__( 'Platform Name', 'enpix-core' ),
							],
							[
								'id'    => 'social_icon',
								'type'  => 'icon',
								'title' => esc_html__( 'Icon', 'enpix-core' ),
							],
							[
								'id'    => 'social_link',
								'type'  => 'text',
								'title' => esc_html__( 'URL', 'enpix-core' ),
							],
						],
						'default'    => [
							[
								'social_name' => 'Facebook',
								'social_icon' => 'fab fa-facebook-f',
								'social_link' => 'https://facebook.com',
							],
							[
								'social_name' => 'Twitter',
								'social_icon' => 'fab fa-twitter',
								'social_link' => 'https://twitter.com',
							],
							[
								'social_name' => 'Pinterest',
								'social_icon' => 'fab fa-pinterest-p',
								'social_link' => 'https://pinterest.com',
							],
							[
								'social_name' => 'Dribbble',
								'social_icon' => 'fab fa-dribbble',
								'social_link' => 'https://dribbble.com',
							],
						],
					],
					[
						'id'         => 'fs_social_title',
						'type'       => 'text',
						'title'      => esc_html__( 'Social Platforms Title', 'enpix-core' ),
						'default'    => esc_html__( 'Follow us on', 'empix-core' ),
						'dependency' => [ 'is_floating_sidebar', '==', 'true' ],
					],
				],
			],
		],
	],
);

CSF::createSection(
	$prefix,
	[
		'parent' => 'header',
		'title'  => esc_html__( 'Menu Settings', 'enpix-core' ),
		'fields' => [
			[
				'id'    => 'menu_color',
				'type'  => 'tabbed',
				'title' => esc_html__( 'Menu Items Color', 'enpix-core' ),
				'tabs'  => [
					[
						'title'  => esc_html__( 'Link Colors', 'enpix-core' ),
						'fields' => [
							[
								'id'      => 'item_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Normal Link Color', 'enpix-core' ),
								'default' => '#212833',
								'output'  => [
									'color' => 'nav.site-menu a, button.side-opener, .enpix-header-2 nav.site-menu a',
									'fill'  => 'button.header-search-button svg path',

								],
							],
							[
								'id'      => 'hover_item_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Link Hover Color', 'enpix-core' ),
								'default' => '#FF6701',
								'output'  => 'nav.site-menu a:hover, .enpix-header-2 nav.site-menu a:hover',
							],
							[
								'id'      => 'active_item_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Active Item Color', 'enpix-core' ),
								'default' => '#FF6701',
								'output'  => 'nav.site-menu ul li.current-menu-item>a',
							],
						],
					],

					[
						'title'  => esc_html__( 'Background Color', 'enpix-core' ),
						'fields' => [
							[
								'id'      => 'menu_bg_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Menu Background', 'enpix-core' ),
								'default' => '#ffffff',
								'output'  => [
									'background' => 'header.page-header',
								],
							],
							[
								'id'     => 'sticky_menu_bg_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Sticky Menu Background', 'enpix-core' ),
								'output' => [
									'background' => 'header.scrolled',
								],
							],
						],
					],
				],
			],

			[
				'id'    => 'dropdown_menu_color',
				'type'  => 'tabbed',
				'title' => esc_html__( 'Dropdown Menu Color', 'enpix-core' ),
				'tabs'  => [
					[
						'title'  => esc_html__( 'Link Color', 'enpix-core' ),
						'fields' => [
							[
								'id'      => 'dropdown_item_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Link Color', 'enpix-core' ),
								'default' => '#212833',
								'output'  => 'nav.site-menu ul li ul a',
							],

							[
								'id'      => 'dropdown_hover_item_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Link Hover Color', 'enpix-core' ),
								'default' => '#FF6701',
								'output'  => 'nav.site-menu ul li ul a:hover',
							],
						],
					],

					[
						'title'  => esc_html__( 'Background Color', 'enpix-core' ),
						'fields' => [
							[
								'id'      => 'dropdown_bg_color',
								'type'    => 'color',
								'title'   => esc_html__( 'BG Color', 'enpix-core' ),
								'default' => '#ffffff',
								'output'  => [
									'background' => 'nav.site-menu ul li ul.dropdown-menu',
								],
							],
							[
								'id'      => 'dropdown_border_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Border Color', 'enpix-core' ),
								'default' => '#f6f6f6',
								'output'  => [
									'border-bottom-color' => 'nav.site-menu ul li ul.dropdown-menu li:not(:last-child)',
								],
							],
						],
					],
				],
			],
		],
	]
);

// Footer Admin Options.
CSF::createSection(
	$prefix,
	[
		'id'    => 'footer',
		'title' => esc_html__( 'Footer', 'enpix-core' ),
		'icon'  => 'fas fa-border-all',
	]
);

// Subscribe Options
CSF::createSection(
	$prefix,
	[
		'parent' => 'footer',
		'title'  => esc_html__( 'Subscribe Form', 'enpix-core' ),
		'fields' => [
			[
				'id'         => 'is_subscribe_area',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Subscribe Area Visibility', 'enpix-core' ),
				'text_on'    => esc_html__( 'Show', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,
			],

			[
				'id'         => 'subscribe_title',
				'type'       => 'text',
				'title'      => esc_html__( 'Subscribe Title', 'enpix-core' ),
				'default'    => esc_html__( 'Join a community of more than 1,50,000+ persons,get the most out of it.', 'enpix-core' ),
				'dependency' => [ 'is_subscribe_area', '==', 'true' ],
			],

			[
				'id'      => 'subscribe_title_color',
				'type'    => 'color',
				'title'   => esc_html__( 'Subscribe Title Color', 'enpix-core' ),
				'default' => '#1D293F',
				'output'  => '.subscribe-area .subscribe-text .title',
			],

			[
				'id'      => 'subscribe_highlight_color',
				'type'    => 'color',
				'title'   => esc_html__( 'Highlighted Text Color', 'enpix-core' ),
				'default' => '#FF6701',
				'output'  => '.subscribe-area .subscribe-text .title span',
			],

			[
				'id'         => 'mailchimp_form_shortcode',
				'type'       => 'text',
				'desc'       => esc_html__( 'Tutorial for creating mailchimp form and getting shortcode', 'enpix-core' ) . '<br>' . esc_url( 'https://docs.themexplosion.com/wp-content/uploads/2022/12/creating-subscribe-form.mp4' ),
				'title'      => esc_html__( 'Mailchimp Form Shortcode', 'enpix-core' ),
				'dependency' => [ 'is_subscribe_area', '==', 'true' ],
			],
		],
	]
);

CSF::createSection(
	$prefix,
	[
		'parent' => 'footer',
		'title'  => esc_html__( 'Footer Section', 'enpix-core' ),
		'fields' => [
			[
				'id'         => 'footer_visibility',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Footer section visibility.', 'enpix-core' ),
				'text_on'    => esc_html__( 'Visible', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hidden', 'enpix-core' ),
				'text_width' => 100,
				'default'    => true,
			],

			[
				'id'         => 'footer_shapes',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Shapes', 'enpix-core' ),
				'text_on'    => esc_html__( 'Show', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,
			],

			[
				'id'       => 'footer_column',
				'type'     => 'select',
				'title'    => esc_html__( 'Footer Columns', 'enpix-core' ),
				'options'  => [
					1 => esc_html__( '1 Column', 'enpix-core' ),
					2 => esc_html__( '2 Columns', 'enpix-core' ),
					3 => esc_html__( '3 Columns', 'enpix-core' ),
					4 => esc_html__( '4 Columns', 'enpix-core' ),
				],
				'default'  => '1',
				'chosen'   => true,
				'settings' => [
					'width' => '33%',
				],
			],

		],
	]
);

CSF::createSection(
	$prefix,
	[
		'parent' => 'footer',
		'title'  => esc_html__( 'Copyright', 'enpix-core' ),
		'fields' => [
			[
				'id'       => 'footer_copyright_text',
				'type'     => 'wp_editor',
				'title'    => esc_html__( 'Copyright Text', 'enpix-core' ),
				'subtitle' => esc_html__( 'Leave the field empty to hide the copyright area', 'enpix-core' ),
				'height'   => '200px',
				'default'  => esc_html__( 'Copyright 2022 Enpix inc.', 'enpix-core' ),
			],

		],
	]
);

// Post Options.
CSF::createSection(
	$prefix,
	[
		'id'    => 'post_archives',
		'title' => esc_html__( 'Archive Pages', 'enpix-core' ),
		'icon'  => 'fas fa-file-alt',
	]
);

// Search Options.
CSF::createSection(
	$prefix,
	[
		'parent' => 'post_archives',
		'title'  => esc_html__( 'Search Archive', 'enpix-core' ),
		'fields' => [
			[
				'id'       => 'search_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Search Page Layout', 'enpix-core' ),
				'options'  => [
					'list' => esc_html__( 'List', 'enpix-core' ),
					'grid' => esc_html__( 'Grid', 'enpix-core' ),
				],
				'default'  => 'grid',
				'chosen'   => true,
				'settings' => [
					'width' => '33%',
				],
			],

			[
				'id'         => 'is_search_title',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Search Title Bar', 'enpix-core' ),
				'text_on'    => esc_html__( 'Show', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,
			],

			[
				'id'         => 'search_title',
				'type'       => 'text',
				'title'      => esc_html__( 'Search Title', 'enpix-core' ),
				'default'    => esc_html__( 'Search results for:', 'enpix-core' ),
				'dependency' => [ 'is_search_title', '==', 'true' ],
			],

			[
				'id'         => 'is_search_sidebar',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Sidebar', 'enpix-core' ),
				'text_on'    => esc_html__( 'Show', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,
			],
		],
	]
);

// Title bar Options.
CSF::createSection(
	$prefix,
	[
		'parent' => 'post_archives',
		'title'  => esc_html__( 'Other Archives', 'enpix-core' ),
		'fields' => [
			[
				'id'       => 'archive_layout',
				'type'     => 'select',
				'title'    => esc_html__( 'Select Archive Layout', 'enpix-core' ),
				'options'  => [
					'list' => esc_html__( 'List', 'enpix-core' ),
					'grid' => esc_html__( 'Grid', 'enpix-core' ),
				],
				'default'  => 'grid',
				'chosen'   => true,
				'settings' => [
					'width' => '33%',
				],
			],

			[
				'id'         => 'is_archive_title',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Archive Title Bar', 'enpix-core' ),
				'text_on'    => esc_html__( 'Show', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,
			],

			[
				'id'         => 'archive_author_title',
				'type'       => 'text',
				'title'      => esc_html__( 'Author Archive Title', 'enpix-core' ),
				'default'    => esc_html__( 'Posts by:', 'enpix-core' ),
				'dependency' => [ 'is_archive_title', '==', 'true' ],
			],

			[
				'id'         => 'archive_date_title',
				'type'       => 'text',
				'title'      => esc_html__( 'Date Archive Title', 'enpix-core' ),
				'default'    => esc_html__( 'Posts on:', 'enpix-core' ),
				'dependency' => [ 'is_archive_title', '==', 'true' ],
			],

			[
				'id'         => 'archive_cat_title',
				'type'       => 'text',
				'title'      => esc_html__( 'Category Archive Title', 'enpix-core' ),
				'default'    => esc_html__( 'Category Archive:', 'enpix-core' ),
				'dependency' => [ 'is_archive_title', '==', 'true' ],
			],

			[
				'id'         => 'archive_tag_title',
				'type'       => 'text',
				'title'      => esc_html__( 'Tag Archive Title', 'enpix-core' ),
				'default'    => esc_html__( 'Tag Archive:', 'enpix-core' ),
				'dependency' => [ 'is_archive_title', '==', 'true' ],
			],

			[
				'id'         => 'is_archive_sidebar',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Archive Sidebar', 'enpix-core' ),
				'text_on'    => esc_html__( 'Show', 'enpix-core' ),
				'text_off'   => esc_html__( 'Hide', 'enpix-core' ),
				'text_width' => 80,
				'default'    => true,
			],
		],
	]
);

// Post Format Options.
CSF::createSection(
	$prefix,
	[
		'id'    => 'post_formats',
		'title' => esc_html__( 'Post Formats', 'enpix-core' ),
		'icon'  => 'fas fa-icons',
	]
);

CSF::createSection(
	$prefix,
	[
		'parent' => 'post_formats',
		'title'  => esc_html__( 'Video', 'enpix-core' ),
		'fields' => [
			[
				'id'      => 'format_video_icon',
				'type'    => 'icon',
				'title'   => esc_html__( 'Icon for video posts', 'enpix-core' ),
				'default' => 'fas fa-play-circle',
			],

			[
				'title'  => esc_html__( 'Icon Color', 'enpix-core' ),
				'id'     => 'format_video_icon_settings',
				'type'   => 'fieldset',
				'fields' => [
					[
						'title'       => esc_html__( 'Normal', 'enpix-core' ),
						'id'          => 'format_video_icon_color',
						'type'        => 'color',
						'output'      => '.post-format-video a',
						'default'     => '#ffffff',
						'output_mode' => 'color',
					],

					[
						'title'       => esc_html__( 'Hover', 'enpix-core' ),
						'id'          => 'format_video_icon_hover',
						'type'        => 'color',
						'output'      => '.post-format-video a:hover',
						'default'     => '#FF6701',
						'output_mode' => 'color',
					],
				],
			],
		],
	]
);

CSF::createSection(
	$prefix,
	[
		'parent' => 'post_formats',
		'title'  => esc_html__( 'Quote', 'enpix-core' ),
		'fields' => [
			[
				'title'       => esc_html__( 'Quote Icons Color', 'enpix-core' ),
				'id'          => 'format_quote_icon_color',
				'type'        => 'color',
				'default'     => '#FF6701',
				'output_mode' => 'color',
				'output'      => [
					'.post-format-link-quote-left svg',
					'.post-format-link-quote-right svg',
				],
			],
		],
	]
);

CSF::createSection(
	$prefix,
	[
		'parent' => 'post_formats',
		'title'  => esc_html__( 'Link', 'enpix-core' ),
		'fields' => [
			[
				'id'      => 'format_link_icon',
				'type'    => 'icon',
				'title'   => esc_html__( 'Icon for link type posts', 'enpix-core' ),
				'default' => 'fas fa-link',
			],

			[
				'title'       => esc_html__( 'Icon Color', 'enpix-core' ),
				'id'          => 'format_link_icon_color',
				'type'        => 'color',
				'default'     => '#FF6701',
				'output_mode' => 'color',
				'output'      => '.post-format-link-icon svg',
			],
		],
	]
);

// Blog admin options.
CSF::createSection(
	$prefix,
	[
		'id'     => 'blog',
		'title'  => esc_html__( 'Blog', 'enpix-core' ),
		'icon'   => 'fas fa-th',
		'fields' => [
			[
				'id'      => 'blog_layout',
				'type'    => 'select',
				'title'   => esc_html__( 'Blog Layout', 'enpix-core' ),
				'options' => [
					'grid' => esc_html__( 'Grid Layout', 'enpix-core' ),
					'list' => esc_html__( 'List Layout', 'enpix-core' ),
				],
				'default' => 'list',
			],

			[
				'id'         => 'is_blog_sidebar',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Sidebar', 'enpix-core' ),
				'text_on'    => 'Show',
				'text_off'   => 'Hide',
				'text_width' => 80,
				'default'    => true,
			],
		],
	]
);

/**
 *  Projects admin options.
 */
CSF::createSection(
	$prefix,
	[
		'id'     => 'projects',
		'title'  => esc_html__( 'Projects', 'enpix-core' ),
		'icon'   => 'fas fa-project-diagram',
		'fields' => [
			[
				'id'      => 'projects_title',
				'type'    => 'text',
				'title'   => __( 'Project Archive Title', 'enpix-core' ),
				'default' => 'Our Portfolio',
			],
		],
	]
);

/**
 *  Team admin options.
 */
CSF::createSection(
	$prefix,
	[
		'id'     => 'team',
		'title'  => esc_html__( 'Team', 'enpix-core' ),
		'icon'   => 'fas fa-users-cog',
		'fields' => [
			[
				'id'         => 'is_team_socials',
				'type'       => 'switcher',
				'title'      => esc_html__( 'Show team member social icons?', 'enpix-core' ),
				'text_on'    => 'Show',
				'text_off'   => 'Hide',
				'text_width' => 80,
				'default'    => true,
			],

			[
				'id'      => 'team_page_title',
				'type'    => 'text',
				'title'   => __( 'Title', 'enpix-core' ),
				'default' => __( 'Powerful Team', 'enpix-core' ),
			],

			[
				'id'      => 'team_page_subtitle',
				'type'    => 'textarea',
				'title'   => esc_html__( 'Subtitle text', 'enpix-core' ),
				'default' => esc_html__( 'Meet our talents team of creative, fun-lovers and magic makers.', 'enpix-html' ),
			],

			//, team_page_subtitle
		],
	]
);

/**
 * 404 page admin options.
 */
CSF::createSection(
	$prefix,
	[
		'id'     => 'error_pg',
		'title'  => esc_html__( '404 Settings', 'enpix-core' ),
		'icon'   => 'fas fa-bug',
		'fields' => [
			[
				'id'           => 'img_404',
				'type'         => 'upload',
				'library'      => 'image',
				'title'        => esc_html__( 'Error Image ( 404 Image )', 'enpix-core' ),
				'subtitle'     => esc_html__( 'Upload your error image here', 'enpix-core' ),
				'button_title' => esc_html__( 'Add Image', 'enpix-core' ),
				'remove_title' => esc_html__( 'Remove Image', 'enpix-core' ),
				'default'      => plugins_url( 'images/404/404.png', __FILE__ ),
			],

			[
				'id'      => 'title_404',
				'type'    => 'text',
				'title'   => esc_html__( 'Title text', 'enpix-core' ),
				'default' => esc_html__( 'We lost this page.', 'enpix-core' ),
			],

			[
				'id'      => 'subtitle_404',
				'type'    => 'textarea',
				'title'   => esc_html__( 'Subtitle text', 'enpix-core' ),
				'default' => esc_html__( 'We searched high and low but couldn’t find what you’re looking for. Let’s find a better place for you to go.' ),
			],

			[
				'id'      => 'button_text_404',
				'type'    => 'text',
				'title'   => esc_html__( 'Button Text', 'enpix-core' ),
				'default' => esc_html__( 'Go Back Home', 'enpix-core' ),
			],
		],
	]
);

/**
 * Custom code admin options.
 */
CSF::createSection(
	$prefix,
	[
		'id'     => 'custom_code',
		'title'  => esc_html__( 'Custom Code', 'enpix-core' ),
		'icon'   => 'fas fa-code',
		'fields' => [
			[
				'id'       => 'custom_css',
				'type'     => 'code_editor',
				'title'    => esc_html__( 'CSS Editor', 'enpix-core' ),
				'subtitle' => esc_html__( 'Type your css code here', 'enpix-core' ),
				'settings' => [
					'theme' => 'mbo',
					'mode'  => 'css',
				],
			],

			[
				'id'       => 'custom_js',
				'type'     => 'code_editor',
				'title'    => esc_html__( 'Javascript Editor', 'enpix-core' ),
				'subtitle' => esc_html__( 'Type your javascript code here', 'enpix-core' ),
				'settings' => [
					'theme' => 'monokai',
					'mode'  => 'javascript',
				],
				'default'  => 'console.log("Hello world");',
			],
		],
	]
);

/**
 * Import export admin options.
 */
CSF::createSection(
	$prefix,
	[
		'id'     => 'export_import',
		'title'  => esc_html__( 'Export/Import', 'enpix-core' ),
		'icon'   => 'fas fa-upload',
		'fields' => [
			[
				'type' => 'backup',
			],
		],
	]
);
