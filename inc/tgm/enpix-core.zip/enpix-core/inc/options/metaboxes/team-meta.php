<?php
defined( 'ABSPATH' ) || exit();

$prefix = 'team-meta';

CSF::createMetabox(
	$prefix,
	[
		'title'     => esc_html__( 'Team Options', 'enpix-core' ),
		'post_type' => 'team',
		'theme'     => 'light',
	]
);

// Create a section.
CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Member Details', 'enpix-core' ),
		'fields' => [
			[
				'id'    => 'member-designation',
				'type'  => 'text',
				'title' => esc_html__( 'Member Designation', 'enpix-core' ),
			],

			[
				'id'     => 'team-social-icons',
				'type'   => 'repeater',
				'title'  => esc_html__( 'Social Media Information', 'enpix-core' ),
				'fields' => [
					[
						'id'    => 'social-icon',
						'type'  => 'icon',
						'title' => esc_html__( 'Social Icon', 'enpix-core' ),
					],

					[
						'id'    => 'social-link',
						'type'  => 'link',
						'title' => esc_html__( 'Link', 'enpix-core' ),
					],

				],
			],
		],
	]
);
