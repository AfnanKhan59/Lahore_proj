<?php
$prefix = 'video_post_meta';

CSF::createMetabox(
	$prefix,
	[
		'title'        => esc_html__( 'Video Options', 'enpix-core' ),
		'post_type'    => 'post',
		'post_formats' => 'video',
	]
);

CSF::createSection(
	$prefix,
	[
		'fields' => [
			[
				'id'      => 'post_video',
				'type'    => 'text',
				'title'   => esc_html__( 'Input Video link', 'enpix-core' ),
				'default' => 'https://www.youtube.com/watch?v=N21J8FHyQCE&ab_channel=INFODROP',
			],
		],
	]
);
