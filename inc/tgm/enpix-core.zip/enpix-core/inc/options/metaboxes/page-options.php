<?php

use function PHPSTORM_META\map;

defined( 'ABSPATH' ) || exit();

$prefix = 'page_options';

$opt                  = get_option( 'enpix_opt' );
$global_header_layout = $opt['header_layout'] ?? 1;

$global_main_logo   = $opt['main_logo'] ['url'] ?? '';
$global_retina_logo = ! empty( $opt['retina_logo']['url'] ) ? "srcset='{$opt['retina_logo']['url']} 2x'" : '';

CSF::createMetabox(
	$prefix,
	[
		'title'     => esc_html__( 'Page Options', 'enpix-core' ),
		'post_type' => 'page',
		'theme'     => 'light',

	]
);

// Header Layout.
CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Header layout', 'enpix-core' ),
		'id'     => 'enpix_page_header',
		'fields' => [
			[
				'id'      => 'page_header_layout',
				'type'    => 'image_select',
				'options' => [
					'1' => plugins_url( '../images/menu/menu-1.png', __FILE__ ),
					'2' => plugins_url( '../images/menu/menu-2.png', __FILE__ ),
				],
				'default' => $global_header_layout,
			],
		],
	]
);

// Logo.
CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Logo', 'enpix-core' ),
		'id'     => 'page_logo',
		'fields' => [
			[
				'id'       => 'page_main_logo',
				'type'     => 'media',
				'title'    => esc_html__( 'Main Logo', 'enpix-core' ),
				'subtitle' => esc_html__( 'Select the main logo for this page.', 'enpix-core' ),
				'default'  => $global_main_logo,
			],
			[
				'id'       => 'page_retina_logo',
				'type'     => 'media',
				'title'    => esc_html__( 'Retina Logo', 'enpix-core' ),
				'subtitle' => esc_html__( 'Select the retina logo for this page.', 'enpix-core' ),
				'default'  => $global_retina_logo,
			],
		],
	]
);

CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Menu Color', 'enpix-core' ),
		'fields' => [
			[
				'id'    => 'page_menu_color',
				'type'  => 'tabbed',
				'title' => esc_html__( 'Menu Items Color', 'enpix-core' ),
				'tabs'  => [
					[
						'title'  => esc_html__( 'Link Colors', 'enpix-core' ),
						'fields' => [
							[
								'id'     => 'page_item_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Menu Item Colors', 'enpix-core' ),
								'output' => [
									'color' => 'nav.site-menu ul li a, button.side-opener, .enpix-header-2 nav.site-menu ul li a',
									'fill'  => 'button.header-search-button svg path',
								],
							],
							[
								'id'     => 'page_hover_item_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Hover Color', 'enpix-core' ),
								'output' => [
									'color' => 'nav.site-menu ul li a:hover, .enpix-header-2 nav.site-menu ul li a:hover',
								],
							],
							[
								'id'     => 'page_active_item_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Active Item Color', 'enpix-core' ),
								'output' => 'nav.site-menu ul li.current-menu-item>a',
							],
						],
					],

					[
						'title'  => esc_html__( 'Background Color', 'enpix-core' ),
						'fields' => [
							[
								'id'      => 'page_menu_bg_color',
								'type'    => 'color',
								'title'   => esc_html__( 'Menu Background', 'enpix-core' ),
								'output'  => [
									'background' => 'header.page-header',
								],
								'default' => 'transparent',
							],
							[
								'id'     => 'page_sticky_menu_bg_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Sticky Menu Background', 'enpix-core' ),
								'output' => [
									'background' => 'header.scrolled',
								],
							],
						],
					],
				],
			],

			[
				'id'    => 'page_dropdown_menu_color',
				'type'  => 'tabbed',
				'title' => esc_html__( 'Dropdown Menu Color', 'enpix-core' ),
				'tabs'  => [
					[
						'title'  => esc_html__( 'Link Color', 'enpix-core' ),
						'fields' => [
							[
								'id'     => 'page_dropdown_item_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Link Color', 'enpix-core' ),
								'output' => 'nav.site-menu ul li ul.dropdown-menu a',
							],

							[
								'id'     => 'page_dropdown_hover_item_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Link Hover Color', 'enpix-core' ),
								'output' => 'nav.site-menu ul li ul.dropdown-menu a:hover',
							],
						],
					],

					[
						'title'  => esc_html__( 'Background Color', 'enpix-core' ),
						'fields' => [
							[
								'id'     => 'page_dropdown_bg_color',
								'type'   => 'color',
								'title'  => esc_html__( 'BG Color', 'enpix-core' ),
								'output' => [
									'background' => 'nav.site-menu ul li ul.dropdown-menu',
								],
							],
							[
								'id'     => 'page_dropdown_border_color',
								'type'   => 'color',
								'title'  => esc_html__( 'Border Color', 'enpix-core' ),
								'output' => [
									'border-bottom-color' => 'nav.site-menu ul li ul.dropdown-menu li:not(:last-child)',
								],
							],
						],
					],
				],
			],
		],
	]
);

// Page title.
CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Page Title Settings', 'enpix-core' ),
		'fields' => [
			[
				'id'      => 'hide_page_title',
				'type'    => 'checkbox',
				'title'   => esc_html__( 'Page Title Visibility', 'enpix-core' ),
				'label'   => esc_html__( 'Hide page title', 'enpix-core' ),
				'default' => false,
			],
			[
				'id'    => 'page_subtitle',
				'type'  => 'textarea',
				'title' => esc_html__( 'Page Subheading', 'enpix-core' ),
			],
		],
	],
);

CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Footer', 'enpix-core' ),
		'fields' => [
			[
				'id'      => 'hide_subscribe_area',
				'type'    => 'checkbox',
				'title'   => esc_html__( 'Subscribe Area', 'enpix-core' ),
				'label'   => esc_html__( 'Hide subscribe area on this page', 'enpix-core' ),
				'default' => false,
			],

			[
				'id'      => 'is_footer_hidden',
				'type'    => 'checkbox',
				'title'   => esc_html__( 'Footer Area', 'enpix-core' ),
				'label'   => esc_html__( 'Hide footer section on this page', 'enpix-core' ),
				'default' => false,
			],

			[
				'id'      => 'hide_copyright_area',
				'type'    => 'checkbox',
				'title'   => esc_html__( 'Copyright Area', 'enpix-core' ),
				'label'   => esc_html__( 'Hide copyright on this page', 'enpix-core' ),
				'default' => false,
			],
		],
	]
);
