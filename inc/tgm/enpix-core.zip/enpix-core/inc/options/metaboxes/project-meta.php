<?php

defined( 'ABSPATH' ) || exit();

$prefix = 'project-meta';

CSF::createMetabox(
	$prefix,
	[
		'title'     => esc_html__( 'Project Options', 'enpix-core' ),
		'post_type' => 'projects',
		'theme'     => 'light',
	]
);

// Create a section.
CSF::createSection(
	$prefix,
	[
		'title'  => esc_html__( 'Project Data', 'enpix-core' ),
		'fields' => [

			[
				'id'    => 'client_name',
				'type'  => 'text',
				'title' => __( 'Client\'s name', 'enpix-core' ),
			],


			[
				'id'    => 'project_date',
				'type'  => 'date',
				'title' => 'Project Date',
			],
		],
	]
);
