<?php
defined( 'ABSPATH' ) || exit();
	$prefix = 'enpix_profile_options';

	CSF::createProfileOptions(
		$prefix,
		[
			'data_type' => 'serialize',
		]
	);

	CSF::createSection(
		$prefix,
		[
			'fields' => [
				[
					'id'    => 'user_designation',
					'type'  => 'text',
					'title' => esc_html__( 'User designation', 'enpix-core' ),
				],
			],
		]
	);
