(function ($) {
    'use strict';
    $(document).ready(function (){
        let button = $("#load-more-btn");
        button.on('click',function (e){
            var nexturl = $(this).attr('href');
            $.get(nexturl,{},function (data){
                var posts = $(data).find("#blog-grid").html();
                // console.log(posts);
                $("#blog-grid").append(posts);
                var newpagelink = $(data).find("#load-more-btn").attr("href");
                if (newpagelink){
                    $("#load-more-btn").attr('href',newpagelink);
                }else {
                    $("#load-more-btn").hide('slow');
                }
            });
            return false;
        });
        var newpagelink = button.attr('href');
        if (!newpagelink){
            $("#load-more-btn").hide('slow');
        }

    });
})(jQuery);
