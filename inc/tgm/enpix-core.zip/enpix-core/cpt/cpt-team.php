<?php
/**
 * Use namespace to avoid conflict
 */
namespace Enpix\Core\PostType;

/**
 * Class team
 * @package PostType
 *
 * Use actual name of post type for
 * easy readability.
 *
 * Potential conflicts removed by namespace
 */
class Team {

	/**
	 * @var string
	 *
	 * Set post type params
	 */
	private $type          = 'team';
	private $slug          = 'team';
	private $name          = 'Team Members';
	private $singular_name = 'Team Member';
	private $icon          = 'dashicons-groups';

	/**
	 * Register post type
	 */
	public function register() {
		$opt    = get_option( 'enpix_opt' );
		$slug   = ! empty( $opt['team_slug'] ) ? strtolower( str_replace( ' ', '', $opt['team_slug'] ) ) : $this->slug;
		$labels = [
			'name'               => $this->name,
			'singular_name'      => $this->singular_name,
			'add_new'            => 'Add New Member',
			'add_new_item'       => 'Add New Member',
			'edit_item'          => 'Edit ' . $this->singular_name,
			'new_item'           => 'New ' . $this->singular_name,
			'all_items'          => 'All ' . $this->name,
			'view_item'          => 'View ' . $this->singular_name,
			'view_items'         => 'View ' . $this->name,
			'search_items'       => 'Search ' . $this->name,
			'not_found'          => 'No ' . strtolower( $this->singular_name ) . ' found',
			'not_found_in_trash' => 'No ' . strtolower( $this->singular_name ) . ' found in Trash',
			'parent_item_colon'  => '',
			'menu_name'          => $this->name,
		];

		$args = [
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => [ 'slug' => $slug ],
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'menu_position'      => 8,
			'supports'           => [ 'title', 'thumbnail', 'editor' ], // 'excerpt', 'author',
			'yarpp_support'      => true,
			'menu_icon'          => $this->icon,
		];

		register_post_type( $this->type, $args );
	}

	/**
	 * @param $columns
	 * @return mixed
	 *
	 * Choose the columns you want in
	 * the admin table for this post
	 */
	public function set_columns( $columns ) {
		// Set/unset post type table columns here

		return $columns;
	}

	/**
	 * @param $column
	 * @param $post_id
	 *
	 * Edit the contents of each column in
	 * the admin table for this post
	 */
	public function edit_columns( $column, $post_id ) {
		// Post type table column content code here
	}

	/**
	 * team constructor.
	 *
	 * When class is instantiated
	 */
	public function __construct() {

		// Register the post type
		add_action( 'init', [ $this, 'register' ] );

		// Admin set post columns
		add_filter( 'manage_edit-' . $this->type . '_columns', [ $this, 'set_columns' ], 10, 1 );

		// Admin edit post columns
		add_action( 'manage_' . $this->type . '_posts_custom_column', [ $this, 'edit_columns' ], 10, 2 );

	}
}
/**
 * Instantiate class, creating post type
 */
new Team();
