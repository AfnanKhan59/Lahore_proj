<?php
/**
 * Use namespace to avoid conflict
 */
namespace Enpix\Core\PostType;

/**
 * Class team
 * @package PostType
 *
 * Use actual name of post type for
 * easy readability.
 *
 * Potential conflicts removed by namespace
 */
class Projects {

	/**
	 * @var string
	 *
	 * Set post type params
	 */
	private $type = 'projects';
	private $slug = 'projects';
	private $icon = 'dashicons-schedule';

	/**
	 * Register post type
	 */
	public function register() {
		$slug   = $this->slug;
		$labels = [
			'name'                  => _x( 'Projects', 'Post type general name', 'enpix-core' ),
			'singular_name'         => _x( 'Project', 'Post type singular name', 'enpix-core' ),
			'menu_name'             => _x( 'Projects', 'Admin Menu text', 'enpix-core' ),
			'name_admin_bar'        => _x( 'Project', 'Add New on Toolbar', 'enpix-core' ),
			'add_new'               => __( 'Add New', 'enpix-core' ),
			'add_new_item'          => __( 'Add New Project', 'enpix-core' ),
			'new_item'              => __( 'New Project', 'enpix-core' ),
			'edit_item'             => __( 'Edit Project', 'enpix-core' ),
			'view_item'             => __( 'View Project', 'enpix-core' ),
			'view_items'            => __( 'View Projects', 'enpix-core' ),
			'all_items'             => __( 'All Projects', 'enpix-core' ),
			'search_items'          => __( 'Search Projects', 'enpix-core' ),
			'parent_item_colon'     => __( 'Parent Projects:', 'enpix-core' ),
			'not_found'             => __( 'No projects found.', 'enpix-core' ),
			'not_found_in_trash'    => __( 'No projects found in Trash.', 'enpix-core' ),
			'featured_image'        => _x( 'Project Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'enpix-core' ),
			'set_featured_image'    => _x( 'Set project image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'enpix-core' ),
			'remove_featured_image' => _x( 'Remove image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'enpix-core' ),
			'use_featured_image'    => _x( 'Use as project image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'enpix-core' ),
			'archives'              => _x( 'Project archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'enpix-core' ),
		];

		$args = [
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => [ 'slug' => $slug ],
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'menu_position'      => 9,
			'show_in_rest'       => true,
			'supports'           => [ 'title', 'thumbnail', 'editor', 'comments', 'revisions', 'categories' ],
			'yarpp_support'      => true,
			'menu_icon'          => $this->icon,
		];

		register_post_type( $this->type, $args );

		register_taxonomy(
			'project-categories',
			$this->type,
			[
				'public'            => true,
				'hierarchical'      => true,
				'show_admin_column' => true,
				'show_in_nav_menus' => false,
				'show_in_rest'      => true,
				'labels'            => [
					'name' => esc_html__( 'Categories', 'enpix-core' ),
				],
			]
		);
	}

	/**
	 * @param $columns
	 * @return mixed
	 *
	 * Choose the columns you want in
	 * the admin table for this post
	 */
	public function set_columns( $columns ) {
		// Set/unset post type table columns here

		return $columns;
	}

	/**
	 * @param $column
	 * @param $post_id
	 *
	 * Edit the contents of each column in
	 * the admin table for this post
	 */
	public function edit_columns( $column, $post_id ) {
		// Post type table column content code here
	}

	/**
	 * team constructor.
	 *
	 * When class is instantiated
	 */
	public function __construct() {

		// Register the post type
		add_action( 'init', [ $this, 'register' ] );

		// Admin set post columns
		add_filter( 'manage_edit-' . $this->type . '_columns', [ $this, 'set_columns' ], 10, 1 );

		// Admin edit post columns
		add_action( 'manage_' . $this->type . '_posts_custom_column', [ $this, 'edit_columns' ], 10, 2 );

	}
}
/**
 * Instantiate class, creating post type
 */
new Projects();
