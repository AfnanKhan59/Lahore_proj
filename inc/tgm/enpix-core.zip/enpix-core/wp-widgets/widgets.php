<?php
// Require widget files
require plugin_dir_path( __FILE__ ) . 'Recent_posts.php';

// Register Widgets
add_action(
	'widgets_init',
	function() {
		register_widget( 'EnpixCore\WpWidgets\Recent_Posts' );
	}
);
