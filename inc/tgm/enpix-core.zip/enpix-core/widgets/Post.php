<?php
namespace Enpix\Core;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use WP_Query;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

function enpix_post_category_list() {
	$post_cat_array = [];
	$elements       = get_categories();
	if ( ! empty( $elements ) ) {
		foreach ( $elements as $element ) {
			$post_cat_array[ $element->term_id ] = $element->name;
		}
	}
	return $post_cat_array;
}

function enpix_post_tag_list() {
	$post_tag_array = [];
	$elements       = get_tags();
	if ( ! empty( $elements ) ) {
		foreach ( $elements as $element ) {
			$post_tag_array[ $element->term_id ] = $element->name;
		}
	}
	return $post_tag_array;
}

function enpix_post_list() {
	$post_array = [];
	$elements   = get_posts( [ 'numberposts' => -1 ] );

	if ( ! empty( $elements ) ) {
		foreach ( $elements as $element ) {
			$post_array[ $element->ID ] = $element->post_title;
		}
	}
	return $post_array;
}

class Post extends Widget_Base {
	public function get_name() {
		return 'enpix_post';
	}

	public function get_title() {
		return esc_html__( 'Blog Post', 'enpix-core' );
	}

	public function get_icon() {
		return 'bl_icon eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'enpix' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'select_layout',
			[
				'label' => esc_html__( 'Layout', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'       => esc_html__( 'Select Layout', 'enpix-core' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'1' => esc_html__( 'Layout 1', 'enpix-core' ),
					'2' => esc_html__( 'Layout 2', 'enpix-core' ),
				],
				'default'     => '1',
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'enpix_blog_posts_sec',
			[
				'label' => esc_html__( 'Blog posts settings', 'enpix-core' ),
			]
		);

		$this->add_control(
			'show_by',
			[
				'label'       => esc_html__( 'Show posts', 'enpix-core' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'1' => esc_html__( '3 latest posts', 'enpix-core' ),
					'2' => esc_html__( 'Based on category and tags', 'enpix-core' ),
					'3' => esc_html__( 'Select posts manually', 'enpix-core' ),
				],
				'default'     => '1',
				'label_block' => true,
			]
		);

		$this->add_control(
			'hr_2',
			[
				'type'      => \Elementor\Controls_Manager::DIVIDER,
				'condition' => [
					'show_by' => '2',
				],
			]
		);

		$this->add_control(
			'post_selection_title_2',
			[
				'label'     => esc_html__( 'Show Posts by Meta Information', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'show_by' => '2',
				],
			]
		);

		$this->add_control(
			'category_list',
			[
				'label'       => esc_html__( 'Select Categories', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => enpix_post_category_list(),
				'multiple'    => true,
				'condition'   => [
					'show_by' => '2',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'tags_list',
			[
				'label'       => esc_html__( 'Select Tags', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => enpix_post_tag_list(),
				'multiple'    => true,
				'condition'   => [
					'show_by' => '2',
				],
				'label_block' => true,
			]
		);

		$this->add_control(
			'hr_3',
			[
				'type'      => \Elementor\Controls_Manager::DIVIDER,
				'condition' => [
					'show_by' => '3',
				],
			]
		);

		$this->add_control(
			'post_selection_title_3',
			[
				'label'     => esc_html__( 'Manual Post Selection', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'condition' => [
					'show_by' => '3',
				],
			]
		);

		$this->add_control(
			'posts_list',
			[
				'label'       => esc_html__( 'Select Posts to Show', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => enpix_post_list(),
				'multiple'    => true,
				'label_block' => true,
				'condition'   => [
					'show_by' => '3',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Post Title', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'title_tabs',
		);

		$this->start_controls_tab(
			'title_normal',
			[
				'label' => esc_html__( 'Normal', 'enpix-core' ),
			]
		);

		$this->add_control(
			'title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-title h2' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_normal_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .post-title h2',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'title_hover',
			[
				'label' => esc_html__( 'Hover', 'enpix-core' ),
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-title h2 a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_hover_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .post-title h2:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'readmore_style',
			[
				'label' => esc_html__( 'Read More', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'readmore_tabs',
		);

		$this->start_controls_tab(
			'readmore_normal',
			[
				'label' => esc_html__( 'Normal', 'enpix-core' ),
			]
		);

		$this->add_control(
			'readmore_normal_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-readmore a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'readmore_normal_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .post-readmore a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'readmore_hover',
			[
				'label' => esc_html__( 'Hover', 'enpix-core' ),
			]
		);

		$this->add_control(
			'readmore_hover_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-readmore a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'readmore_hover_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .post-readmore a:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'meta_style',
			[
				'label' => esc_html__( 'Post Meta', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'meta_tabs',
		);

		$this->start_controls_tab(
			'meta_normal',
			[
				'label' => esc_html__( 'Normal', 'enpix-core' ),
			]
		);

		$this->add_control(
			'meta_normal_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-meta a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'meta_normal_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .post-meta a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'meta_hover',
			[
				'label' => esc_html__( 'Hover', 'enpix-core' ),
			]
		);

		$this->add_control(
			'meta_hover_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-meta a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'meta_hover_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .post-meta a:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'cat_badge_style',
			[
				'label' => esc_html__( 'Category Badge', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'cat_badge_tabs',
		);

		$this->start_controls_tab(
			'cat_badge_normal',
			[
				'label' => esc_html__( 'Normal', 'enpix-core' ),
			]
		);

		$this->add_control(
			'cat_badge_normal_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.category-badge' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cat_badge_normal_bg',
			[
				'label'     => esc_html__( 'Background', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.category-badge' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'cat_badge_normal_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} a.category-badge',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cat_badge_hover',
			[
				'label' => esc_html__( 'Hover', 'enpix-core' ),
			]
		);

		$this->add_control(
			'cat_badge_hover_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.category-badge:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'cat_badge_hover_bg',
			[
				'label'     => esc_html__( 'Background', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a.category-badge:hover' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'cat_badge_hover_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} a.category-badge:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		$post_cats = ! empty( $settings['category_list'] ) ? $settings['category_list'] : '';
		$post_tags = ! empty( $settings['tags_list'] ) ? $settings['tags_list'] : '';
		$post_list = ! empty( $settings['posts_list'] ) ? $settings['posts_list'] : '';

		$args = [
			'post_type'           => 'post',
			'posts_per_page'      => 3,
			'ignore_sticky_posts' => true,
		];

		if ( $settings['show_by'] == 2 && ! empty( $post_cats ) ) {
			$args['cat'] = implode( ', ', $post_cats );
		}

		if ( $settings['show_by'] == 2 && ! empty( $post_tags ) ) {
			$args['tag_id'] = implode( ', ', $post_tags );
		}

		if ( $settings['show_by'] == 3 && ! empty( $post_list ) ) {
			$args['post__in']       = $post_list;
			$args['posts_per_page'] = -1;
		}

		$posts = new WP_Query( $args );

		include "inc/posts/post-{$settings['layout']}.php";
	}
}
