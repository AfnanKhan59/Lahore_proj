<?php
namespace Enpix\Core;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Hero extends Widget_Base {
	public function get_name() {
		return 'enpix_hero';
	}

	public function get_title() {
		return esc_html__( 'Hero Banner', 'enpix-core' );
	}

	public function get_icon() {
		return 'bl_icon eicon-device-desktop';
	}

	public function get_categories() {
		return [ 'enpix' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'choose_style',
			[
				'label' => esc_html__( 'Choose Style', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'hero_layout',
			[
				'label'   => esc_html__( 'Choose Layout', 'enpix-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'1' => esc_html__( 'Layout One', 'enpix-core' ),
					'2' => esc_html__( 'Layout Two', 'enpix-core' ),
				],
				'default' => '1',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'hero_contents',
			[
				'label' => esc_html__( 'Hero Contents', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'is_arrows',
			[
				'label'        => esc_html__( 'Show Slider Arrows', 'enpix-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'enpix-core' ),
				'label_off'    => esc_html__( 'Hide', 'enpix-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'is_shapes',
			[
				'label'        => esc_html__( 'Show shapes', 'enpix-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'enpix-core' ),
				'label_off'    => esc_html__( 'Hide', 'enpix-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'hero_title',
			[
				'label'       => esc_html__( 'Hero Title', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => __( 'Text between &#60;span&#62; and &#60;/span&#60; will be highlighted', 'enpix-core' ),
			]
		);

		$repeater->add_control(
			'hero_description',
			[
				'label' => esc_html__( 'Hero Description', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::TEXTAREA,
				'rows'  => 10,
			]
		);

		$repeater->add_control(
			'slider_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'hero_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::TEXT,
			]
		);

		$repeater->add_control(
			'hero_btn',
			[
				'label'       => esc_html__( 'Button URL', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'default'     => [
					'url'               => '#',
					'is_external'       => true,
					'nofollow'          => true,
					'custom_attributes' => '',
				],
				'placeholder' => esc_html__( 'https://example.com', 'enpix-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'slider_separator_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'hero_img',
			[
				'label' => esc_html__( 'Hero Image', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'hero_repeater',
			[
				'label'       => esc_html__( 'Banner Slides', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'hero_title'       => __( 'Digital <span>product</span> design agency', 'enpix-core' ),
						'hero_description' => esc_html__( 'Create live segments and target the right people for messages based on their behaviors.', 'enpix-core' ),
						'hero_btn_text'    => esc_html__( 'Get Started', 'enpix-core' ),
						'hero_btn'         => [
							'url'               => esc_url( 'https://example.com', 'enpix-core' ),
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
						'hero_img'         => [
							'url' => esc_attr( WID_IMG ) . 'home/banner/banner-1.png',
						],
					],
					[
						'hero_title'       => __( 'Digital <span>product</span> design agency', 'enpix-core' ),
						'hero_description' => esc_html__( 'Create live segments and target the right people for messages based on their behaviors.', 'enpix-core' ),
						'hero_btn_text'    => esc_html__( 'Get Started', 'enpix-core' ),
						'hero_btn'         => [
							'url'               => esc_url( 'https://example.com', 'enpix-core' ),
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
						'hero_img'         => [
							'url' => esc_attr( WID_IMG ) . 'home/banner/banner-2.png',
						],
					],
					[
						'hero_title'       => __( 'Digital <span>product</span> design agency', 'enpix-core' ),
						'hero_description' => esc_html__( 'Create live segments and target the right people for messages based on their behaviors.', 'enpix-core' ),
						'hero_btn_text'    => esc_html__( 'Get Started', 'enpix-core' ),
						'hero_btn'         => [
							'url'               => esc_url( 'https://example.com', 'enpix-core' ),
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
						'hero_img'         => [
							'url' => esc_attr( WID_IMG ) . 'home/banner/banner-3.png',
						],
					],
				],
				'title_field' => '{{{ hero_title }}}',
				'condition'   => [
					'hero_layout' => '1',
				],
			]
		);

		$repeater_2 = new \Elementor\Repeater();

		$repeater_2->add_control(
			'hero_title',
			[
				'label'       => esc_html__( 'Hero Title', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => __( 'Text between &#60;span&#62; and &#60;/span&#60; will be highlighted', 'enpix-core' ),
			]
		);

		$repeater_2->add_control(
			'hero_description',
			[
				'label' => esc_html__( 'Hero Description', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::TEXTAREA,
				'rows'  => 10,
			]
		);

		$repeater_2->add_control(
			'slider_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$repeater_2->add_control(
			'hero_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::TEXT,
			]
		);

		$repeater_2->add_control(
			'hero_btn',
			[
				'label'       => esc_html__( 'Button URL', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'default'     => [
					'url'               => '#',
					'is_external'       => true,
					'nofollow'          => true,
					'custom_attributes' => '',
				],
				'placeholder' => esc_html__( 'https://example.com', 'enpix-core' ),
				'label_block' => true,
			]
		);

		$repeater_2->add_control(
			'slider_separator_2',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$repeater_2->add_control(
			'video_link',
			[
				'label' => esc_html__( 'Video Link', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::URL,
			]
		);

		$repeater_2->add_control(
			'hero_img',
			[
				'label' => esc_html__( 'Hero Image', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'hero_repeater_2',
			[
				'label'       => esc_html__( 'Banner Slides', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater_2->get_controls(),
				'default'     => [
					[
						'hero_title'       => __( 'Web design & Build Uniqe Things', 'enpix-core' ),
						'hero_description' => esc_html__( 'We create and evolve web and mobile apps, marketing websites, two-sided platforms through branding, web design, UX/UI design & app development.', 'enpix-core' ),
						'hero_btn_text'    => esc_html__( 'Start a Project', 'enpix-core' ),
						'hero_btn'         => [
							'url'               => esc_url( 'https://example.com', 'enpix-core' ),
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
						'video_link'       => [
							'url' => 'https://www.youtube.com/watch?v=4zDJRtYrlcU',
						],
						'hero_img'         => [
							'url' => esc_attr( WID_IMG ) . 'home2/banner/banner-1.png',
						],
					],
					[
						'hero_title'       => __( 'Web design & Build Uniqe Things', 'enpix-core' ),
						'hero_description' => esc_html__( 'We create and evolve web and mobile apps, marketing websites, two-sided platforms through branding, web design, UX/UI design & app development.', 'enpix-core' ),
						'hero_btn_text'    => esc_html__( 'Start a Project', 'enpix-core' ),
						'hero_btn'         => [
							'url'               => esc_url( 'https://example.com', 'enpix-core' ),
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
						'video_link'       => [
							'url' => 'https://www.youtube.com/watch?v=4zDJRtYrlcU',
						],
						'hero_img'         => [
							'url' => esc_attr( WID_IMG ) . 'home2/banner/banner-2.png',
						],
					],
					[
						'hero_title'       => __( 'Web design & Build Uniqe Things', 'enpix-core' ),
						'hero_description' => esc_html__( 'We create and evolve web and mobile apps, marketing websites, two-sided platforms through branding, web design, UX/UI design & app development.', 'enpix-core' ),
						'hero_btn_text'    => esc_html__( 'Start a Project', 'enpix-core' ),
						'hero_btn'         => [
							'url'               => esc_url( 'https://example.com', 'enpix-core' ),
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
						'video_link'       => [
							'url' => 'https://www.youtube.com/watch?v=4zDJRtYrlcU',
						],
						'hero_img'         => [
							'url' => esc_attr( WID_IMG ) . 'home2/banner/banner-3.png',
						],
					],
				],
				'title_field' => '{{{ hero_title }}}',
				'condition'   => [
					'hero_layout' => '2',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'banner_head_styles',
			[
				'label' => esc_html__( 'Banner Title', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'banner_head_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#212833',
				'selectors' => [
					'{{WRAPPER}} .banner-text h1' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'banner_head_color_focus',
			[
				'label'     => esc_html__( 'Marked Text Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF6701',
				'selectors' => [
					'{{WRAPPER}} .banner-text h1 span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'banner_head_typography',
				'selector' => '{{WRAPPER}} .banner-text h1, {{WRAPPER}} .banner-text-2 h1',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'banner_desc_styles',
			[
				'label' => esc_html__( 'Banner Text', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'banner_desc_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#4D4E50',
				'selectors' => [
					'{{WRAPPER}} .banner-text p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'banner_desc_typography',
				'selector' => '{{WRAPPER}} .banner-text p',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'banner_button_styles',
			[
				'label' => esc_html__( 'Button', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'banner_button_styles_tab'
		);

		$this->start_controls_tab(
			'banner_button_styles_normal',
			[
				'label' => esc_html__( 'Normal', 'enpix-core' ),
			]
		);

		$this->add_control(
			'banner_button_color',
			[
				'label'     => esc_html__( 'Text Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .banner-text a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'banner_button_bg',
			[
				'label'     => esc_html__( 'Background Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#212833',
				'selectors' => [
					'{{WRAPPER}} .banner-text a' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'banner_button_typo',
				'selector' => '{{WRAPPER}} .banner-text a',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'banner_button_border',
				'selector' => '{{WRAPPER}} .banner-text a',
			]
		);

		$this->add_control(
			'banner_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'text_domain' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .banner-text a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'banner_button_styles_hover',
			[
				'label' => esc_html__( 'Hover', 'enpix-core' ),
			]
		);

		$this->add_control(
			'banner_button_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .banner-text a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'banner_button_bg_hover',
			[
				'label'     => esc_html__( 'Background Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ff6701',
				'selectors' => [
					'{{WRAPPER}} .banner-text a:hover' => 'background: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'banner_button_typo_hover',
				'selector' => '{{WRAPPER}} .banner-text a:hover',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'banner_button_border_hover',
				'selector' => '{{WRAPPER}} .banner-text a:hover',
			]
		);

		$this->add_control(
			'banner_button_padding_hover',
			[
				'label'      => esc_html__( 'Padding', 'text_domain' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .banner-text a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		include "inc/hero/hero-{$settings['hero_layout']}.php";
	}
}
