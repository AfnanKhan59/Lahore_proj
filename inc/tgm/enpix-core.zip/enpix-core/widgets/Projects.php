<?php
namespace Enpix\Core;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use WP_Query;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

function enpix_projects_list() {
	$projects_array = [];
	$elements       = get_posts(
		[
			'post_type'   => 'projects',
			'numberposts' => -1,
		]
	);

	if ( ! empty( $elements ) ) {
		foreach ( $elements as $element ) {
			$projects_array[ $element->ID ] = $element->post_title;
		}
	}

	return $projects_array;
}

function enpix_projects_category_list() {
	$project_cat_args = [ 'hide_empty' => false ];

	$terms = get_terms( 'project-categories', $project_cat_args );
	$projects_cat_array = [];
	if ( ! empty( $terms ) ) {
		foreach ( $terms as $element ) {
			$projects_cat_array[ $element->slug ] = $element->name;
		}
	}
	return $projects_cat_array;
}

class Projects extends Widget_Base {
	public function get_name() {
		return 'enpix_projects';
	}

	public function get_title() {
		return esc_html__( 'Projects', 'enpix-core' );
	}

	public function get_icon() {
		return 'bl_icon eicon-posts-justified';
	}

	public function get_categories() {
		return [ 'enpix' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'choose_style',
			[
				'label' => esc_html__( 'Choose Style', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'portfolio_layout',
			[
				'label'   => esc_html__( 'Choose Layout', 'enpix-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'1' => esc_html__( 'Layout One', 'enpix-core' ),
					'2' => esc_html__( 'Layout Two', 'enpix-core' ),
				],
				'default' => '1',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'enpix_projects_sec',
			[
				'label' => esc_html__( 'Portfolio Settings', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_by',
			[
				'label'       => esc_html__( 'Select Query', 'enpix-core' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'1' => esc_html__( 'Show Latest Projects', 'enpix-core' ),
					'2' => esc_html__( 'Select Projects Manually', 'enpix-core' ),
				],
				'default'     => '1',
				'label_block' => true,
				'condition'   => [
					'portfolio_layout' => '1',
				],
			]
		);

		$this->add_control(
			'projects_count',
			[
				'label'     => esc_html__( 'Select Count', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'step'      => 1,
				'default'   => 5,
				'condition' => [
					'show_by'          => '1',
					'portfolio_layout' => '1',
				],
			]
		);

		$this->add_control(
			'projects_list',
			[
				'label'       => esc_html__( 'Select Projects to Show', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => enpix_projects_list(),
				'multiple'    => true,
				'label_block' => true,
				'condition'   => [
					'show_by'          => '2',
					'portfolio_layout' => '1',
				],
			]
		);

		$this->add_control(
			'portfolio_title',
			[
				'label'       => esc_html__( 'Portfolio Title', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => esc_html__( 'The Work we did for client.', 'enpix-core' ),
				'label_block' => true,
				'condition'   => [
					'portfolio_layout' => '2',
				],
			]
		);

		$this->add_control(
			'category_list',
			[
				'label'       => esc_html__( 'Select Categories', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => enpix_projects_category_list(),
				'multiple'    => true,
				'label_block' => true,
				'condition'   => [
					'portfolio_layout' => '2',
				],
				'description' => 'Mixitup navbar will be visible if 2 or more categories are added.',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'project_title_style',
			[
				'label' => esc_html__( 'Project Title', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'project_title_tabs',
		);

		$this->start_controls_tab(
			'project_title_normal',
			[
				'label' => esc_html__( 'Normal', 'enpix-core' ),
			]
		);

		$this->add_control(
			'project_title_normal_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-text h3 a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'project_title_normal_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .project-text h3 a',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'project_title_hover',
			[
				'label' => esc_html__( 'Hover', 'enpix-core' ),
			]
		);

		$this->add_control(
			'project_title_hover_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-text h3 a:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'project_title_hover_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .project-text h3 a:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'project_cat_style',
			[
				'label' => esc_html__( 'Project Category', 'project_title' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'project_cat_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .project-details p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'project_cat_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .project-details p',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		$projects_count = ! empty( $settings['projects_count'] ) ? $settings['projects_count'] : 5;
		$projects_list  = ! empty( $settings['projects_list'] ) ? $settings['projects_list'] : '';

		$args = [
			'post_type'      => 'projects',
			'posts_per_page' => $projects_count,
		];

		if ( $settings['portfolio_layout'] == 1 && $settings['show_by'] == 2 && ! empty( $projects_list ) ) {
			$args['post__in']       = $projects_list;
			$args['posts_per_page'] = -1;
			$args['order']          = 'ASC';
			$args['orderby']        = 'post__in';
		}

		$project_cats = $settings['category_list'] ?? '';

		if ( $settings['portfolio_layout'] == 2 && ! empty( $project_cats ) ) {
			$args['posts_per_page'] = -1;
			$args['tax_query']      = [
				[
					'taxonomy' => 'project-categories',
					'field'    => 'slug',
					'terms'    => $project_cats,
				],
			];
		}

		$projects = new WP_Query( $args );

		include "inc/projects/project-{$settings['portfolio_layout']}.php";
	}
}
