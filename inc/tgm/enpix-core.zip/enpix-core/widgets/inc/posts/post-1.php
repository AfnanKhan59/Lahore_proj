<div class="blog-grid">
	<?php
	while ( $posts->have_posts() ) :
		$posts->the_post();
		$cat_array = get_the_category();

		$post_format = get_post_format() ? get_post_format() : 'standard';
		include "post-formats/layout-1/content-{$post_format}.php";
	endwhile;
	wp_reset_postdata();
	?>
</div>
