<div class="blog-grid">
	<?php
	while ( $posts->have_posts() ) :
		$posts->the_post();
		$cat_array = array_slice( get_the_category(), 0, 2 );

		$post_format = get_post_format() ? get_post_format() : 'standard';
		include "post-formats/layout-2/content-{$post_format}.php";
	endwhile;
	wp_reset_postdata();
	?>
</div>
