<div <?php post_class( 'enpix-post-item m-0' ); ?>>
	<div class="relative">
		<div class="post-thumbnail">
			<a href="<?php esc_url( the_permalink() ); ?>">
				<?php the_post_thumbnail( 'enpix_595x391' ); ?>
			</a>
		</div>
		<div class="post-meta">
			<div class="post-category">
				<?php foreach ( $cat_array as $post_cat ) : ?>
					<a href="<?php echo esc_url( home_url( "/category/{$post_cat->slug}" ) ); ?>"><?php echo esc_html( ucfirst( $post_cat->name ) ); ?></a>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="post-title">
			<h2>
				<a href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</h2>
		</div>
		<div class="post-readmore">
			<a href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'enpix' ); ?> <i class="fa-solid fa-arrow-right-long"></i></a>
		</div>
	</div>
</div>
