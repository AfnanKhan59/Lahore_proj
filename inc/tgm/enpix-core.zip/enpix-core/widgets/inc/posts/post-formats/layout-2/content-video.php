<?php
$opt = get_option( 'enpix_opt' );

$meta       = get_post_meta( get_the_ID(), 'video_post_meta', true );
$video_url  = $meta['post_video'] ?? '';
$video_icon = $opt['format_video_icon'] ?? 'fas fa-play-circle';
?>

<div <?php post_class( 'enpix-post-item' ); ?>>
	<div class="relative">
		<div class="post-thumbnail">
			<?php
			the_post_thumbnail( 'enpix_595x391' );
			if ( $video_url ) :
				?>
				<div class="post-format-video">
					<a href="<?php echo esc_url( $video_url ); ?>" class="popup-video">
						<i class="<?php echo esc_attr( $video_icon ); ?>"></i>
					</a>
				</div>
			<?php endif; ?>
		</div>
		<div class="post-meta">
			<div class="post-category">
				<?php foreach ( $cat_array as $post_cat ) : ?>
					<a href="<?php echo esc_url( home_url( "/category/{$post_cat->slug}" ) ); ?>"><?php echo esc_html( ucfirst( $post_cat->name ) ); ?></a>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="post-title">
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		</div>
		<div class="post-readmore">
			<a href="<?php the_permalink(); ?>">
				<?php esc_html_e( 'Read more', 'enpix' ); ?><i class="fa-solid fa-arrow-right-long"></i>
			</a>
		</div>
	</div>
</div>
