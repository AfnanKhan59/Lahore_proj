<div <?php post_class( 'enpix-post-item' ); ?>>
	<div class="relative">
	<div class="post-format-quote-icon-left">
			<i class="fa-solid fa-quote-left"></i>
		</div>
		<div class="">
			<h2 class="m-0"><?php the_content(); ?></h2>
		</div>
		<div class="post-format-quote-icon-right">
			<i class="fa-solid fa-quote-right"></i>
		</div>
	</div>
</div>
