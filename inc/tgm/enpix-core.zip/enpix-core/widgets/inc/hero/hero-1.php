<?php

$slide_items = $settings['hero_repeater'];
$is_shapes   = $settings['is_shapes'];
$is_arrows   = ! empty( $settings['is_arrows'] ) ? 'true' : 'false';
?>

<section class="splide banner-slider" id="bannerslider">
	<div class="splide__track overflow-visible">
		<ul class="splide__list">
			<?php foreach ( $slide_items as $item ) : ?>
				<li class="splide__slide">
					<div class="banner-area">
						<div class="container">
							<div class="row">
								<div class="col-lg-6 col-md-7">
									<div class="d-flex align-items-center h-100 relative">
										<div class="banner-text">
											<h1>
												<?php
												echo wp_kses(
													$item['hero_title'],
													[
														'span' => [],
													]
												);
												?>
											</h1>
											<p class="enpix-subtitle-2"><?php echo esc_html( $item['hero_description'] ); ?></p>
											<?php
											if ( ! empty( $item['hero_btn']['url'] ) ) {
												$this->remove_render_attribute( 'hero_btn' );
												$this->add_link_attributes( 'hero_btn', $item['hero_btn'], true );
											}
											?>
											<a <?php $this->print_render_attribute_string( 'hero_btn' ); ?>><?php echo esc_html( $item['hero_btn_text'] ); ?></a>
										</div>

										<!-- SVG Shapes -->
										<?php if ( $is_shapes ) : ?>
											<img class="path-svg" src="<?php echo esc_attr( WID_IMG ); ?>Path.svg" alt="enpix">
											<img class="rectangle-svg" src="<?php echo esc_attr( WID_IMG ); ?>Rectangle.svg" alt="enpix">
											<img class="oval-svg" src="<?php echo esc_attr( WID_IMG ); ?>Oval.svg" alt="enpix">
										<?php endif; ?>
									</div>
								</div>
								<div class="col-lg-6 col-md-5">
									<div class="banner-image-area">
										<?php if ( ! empty( $item['hero_img']['url'] ) ) : ?>
											<img class="banner-image" src="<?php echo esc_url( $item['hero_img']['url'] ); ?>" alt="<?php echo esc_attr( \Elementor\Control_Media::get_image_alt( $item['hero_img'] ) ); ?>">
										<?php endif; ?>
										<div class="banner-image-svg relative">
											<?php if ( $is_shapes ) : ?>
												<img src="<?php echo esc_attr( WID_IMG ); ?>Ellipse14.svg" alt="enpix">
												<img src="<?php echo esc_attr( WID_IMG ); ?>Ellipse13.svg" alt="enpix">
											<?php endif; ?>
										</div>

										<!-- SVG Shapes -->
										<?php if ( $is_shapes ) : ?>
											<img class="fill-255" src="<?php echo esc_attr( WID_IMG ); ?>Group21.svg" alt="enpix">
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="splide__arrows">
		<button class="splide__arrow splide__arrow--prev">
			<svg width="18" height="8" viewBox="0 0 18 8" fill="none"
				xmlns="http://www.w3.org/2000/svg">
				<path d="M4 1.28906L1.5 3.78906L4 6.28906M16.5 3.78906H1.5H16.5Z"
					stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
			</svg>
		</button>
		<button class="splide__arrow splide__arrow--next">
			<svg width="18" height="8" viewBox="0 0 18 8" fill="none"
				xmlns="http://www.w3.org/2000/svg">
				<path d="M14 6.28906L16.5 3.78906L14 1.28906M1.5 3.78906H16.5H1.5Z"
					stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
			</svg>
		</button>
	</div>
</section>

<script>
	// Initialize Banner Slider.
	new Splide('#bannerslider', {
		rewind: true,
		type: 'fade',
		speed: 1500,
		pagination: false,
		arrows: <?php echo esc_html( $is_arrows ); ?>,
	}).mount();
</script>
