<?php

$slide_items = $settings['hero_repeater_2'];
$is_shapes   = $settings['is_shapes'];
$is_arrows   = ! empty( $settings['is_arrows'] ) ? 'true' : 'false';

?>

<section class="splide banner-slider-2" id="bannerslider2">
	<div class="splide__track overflow-visible">
		<ul class="splide__list">
			<?php foreach ( $slide_items as $item ) : ?>
				<li class="splide__slide">
					<div class="banner-area-2">
						<div class="container">
							<div class="row">
								<div class="col-xl-6">
									<div class="d-flex align-items-center h-100 relative">
										<div class="banner-text-2">
											<h1><?php echo esc_html( $item['hero_title'] ); ?></h1>
											<p><?php echo esc_html( $item['hero_description'] ); ?></p>
											<?php
											if ( ! empty( $item['hero_btn']['url'] ) ) {
												$this->remove_render_attribute( 'hero_btn' );
												$this->add_link_attributes( 'hero_btn', $item['hero_btn'] );
											}
											?>
											<a <?php $this->print_render_attribute_string( 'hero_btn' ); ?>>
												<?php echo esc_html( $item['hero_btn_text'] ); ?>
												<svg width="20" height="21" viewBox="0 0 20 21" fill="none"
													xmlns="http://www.w3.org/2000/svg">
													<path d="M15 13L17.5 10.5L15 8M2.5 10.5H17.5H2.5Z"
														stroke-width="1.5" stroke-linecap="round"
														stroke-linejoin="round" />
												</svg>
											</a>
										</div>
									</div>
								</div>
								<div class="col-xl-6">
									<div class="banner-image-area-2 relative">
										<?php if ( ! empty( $item['hero_img']['url'] ) ) : ?>
											<img src="<?php echo esc_url( $item['hero_img']['url'] ); ?>" alt="<?php echo esc_attr( \Elementor\Control_Media::get_image_alt( $item['hero_img'] ) ); ?>">
										<?php endif; ?>
										<div class="video-play-icon">
											<a class="popup-video"
												href="<?php echo esc_url( $item['video_link']['url'] ); ?>">
												<svg width="28" height="37" viewBox="0 0 28 37" fill="none"
													xmlns="http://www.w3.org/2000/svg">
													<path
														d="M4.47652 1.75485C3.15096 0.826962 1.32959 1.77527 1.32959 3.39331V33.5311C1.32959 35.1491 3.15096 36.0975 4.47651 35.1696L26.0035 20.1007C27.1409 19.3045 27.1409 17.6199 26.0035 16.8237L4.47652 1.75485Z"
														stroke-width="1.5" stroke-linecap="round"
														stroke-linejoin="round" />
												</svg>
											</a>
										</div>
										<div class="video-play-icon-layer-2"></div>
										<div class="video-play-icon-layer-3"></div>
										<div class="banner-image-svg-2">
											<img src="<?php echo esc_attr( WID_IMG ); ?>/home2/banner/Ellipse16.svg" alt="enpix">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="splide__arrows mt-80">
		<button class="splide__arrow splide__arrow--prev">
			<svg width="18" height="8" viewBox="0 0 18 8" fill="none"
				xmlns="http://www.w3.org/2000/svg">
				<path d="M4 1.28906L1.5 3.78906L4 6.28906M16.5 3.78906H1.5H16.5Z"
					stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
			</svg>
		</button>
		<button class="splide__arrow splide__arrow--next">
			<svg width="18" height="8" viewBox="0 0 18 8" fill="none"
				xmlns="http://www.w3.org/2000/svg">
				<path d="M14 6.28906L16.5 3.78906L14 1.28906M1.5 3.78906H16.5H1.5Z"
					stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
			</svg>
		</button>
	</div>
</section>

<script>
	var bannerSlider2 = document.querySelectorAll('#bannerslider2')

	if (bannerSlider2.length > 0) {
		new Splide('#bannerslider2', {
			rewind: true,
			type: 'fade',
			speed: 1500,
			pagination: false,
		}).mount();
	}
</script>
