<?php
$service_array = ! empty( $settings['service_array'] ) ? $settings['service_array'] : '';
?>

<div class="ideas-area">
	<table class="idea-categories">
		<tbody>
			<?php foreach ( $service_array as $service ) : ?>
				<tr>
					<td class="idea-logo">
						<?php \Elementor\Icons_Manager::render_icon( $service['service_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</td>
					<td class="idea-title">
						<h3 class="heading-5"><?php echo esc_html( $service['service_title'] ); ?></h3>
					</td>
					<td class="idea-text">
						<p class="enpix-body-text-2 m-0"><?php echo esc_html( $service['service_desc'] ); ?></p>
					</td>
					<td class="idea-url">
						<a href="<?php echo esc_url( $service['service_link']['url'] ); ?>" target="<?php echo esc_attr( $service['service_link']['is_external'] ? '_blank' : '' ); ?>" rel="<?php echo esc_attr( $service['service_link']['nofollow'] ? 'nofollow' : '' ); ?>">
							<svg width="18" height="15" viewBox="0 0 18 15" fill="none"
								xmlns="http://www.w3.org/2000/svg">
								<path
									d="M11.0391 0.886475L9.96094 1.9646L15.0469 7.05054H0V8.55054H15.0469L9.96094 13.6365L11.0391 14.7146L17.4141 8.3396L17.9297 7.80054L17.4141 7.26147L11.0391 0.886475Z"
									fill="#4D4E50" />
							</svg>
						</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>
