<?php
$review_contents = $settings['review_repeater'];
$is_icon         = $settings['is_icon'];
$is_arrows       = $settings['is_arrows'] ? 'true' : 'false';
?>

<div class="reviews-area">
	<?php if ( $is_icon ) : ?>
	<img src="<?php echo esc_attr( WID_IMG ); ?>quote.svg" alt="enpix">
	<?php endif; ?>
	<div class="splide" id="reviewSlider">
		<div class="splide__track">
			<ul class="splide__list">
				<?php foreach ( $review_contents as $review ) : ?>
					<li class="splide__slide">
						<div class="reviews-container">
							<div class="review-text">
								<p><?php echo esc_html( $review['review_text'] ); ?></p>
							</div>
							<div class="review-author">
								<h3 class="enpix-subtitle-3 m-0"><?php echo esc_html( $review['reviewer'] ); ?></h3>
								<p class=" enpix-body-small-1 m-0"><?php echo esc_html( $review['designation'] ); ?>, <?php echo esc_html( $review['company'] ); ?></p>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<div class="splide__arrows mt-80">
			<button class="splide__arrow splide__arrow--prev">
				<svg width="18" height="8" viewBox="0 0 18 8" fill="none"
					xmlns="http://www.w3.org/2000/svg">
					<path d="M4 1.28906L1.5 3.78906L4 6.28906M16.5 3.78906H1.5H16.5Z"
						stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
				</svg>
			</button>
			<button class="splide__arrow splide__arrow--next">
				<svg width="18" height="8" viewBox="0 0 18 8" fill="none"
					xmlns="http://www.w3.org/2000/svg">
					<path d="M14 6.28906L16.5 3.78906L14 1.28906M1.5 3.78906H16.5H1.5Z"
						stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
				</svg>
			</button>
		</div>
	</div>
</div>

<script>
// Initialize Review Slider.
var reviewSlider = document.querySelectorAll('#reviewSlider')

if (reviewSlider.length > 0) {
	new Splide('#reviewSlider', {
		rewind: true,
		type: 'loop',
		speed: 600,
		pagination: false,
		arrows: <?php echo esc_html( $is_arrows ); ?>
	}).mount();
}
</script>
