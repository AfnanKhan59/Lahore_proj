<div class="projects-container pt-80">
	<?php while ( $projects->have_posts() ) :
		$projects->the_post();
		$project_cat_object_array = get_the_terms( get_the_ID(), 'project-categories' );
		$project_cat_array        = [];

		if ( ! empty( $project_cat_object_array ) ) {
			foreach ( $project_cat_object_array as $element ) {
				array_push( $project_cat_array, $element->name );
			}
		}
		?>
		<div class="project-box">
			<div class="project-thumbnail">
				<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'enpix_630x401' ); ?></a>
			</div>
			<div class="project-details pt-35">
				<div class="row">
					<div class="col-9">
						<div class="project-text">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<p class="enpix-body-text-2"><?php echo esc_html( implode( ', ', $project_cat_array ) ); ?></p>
						</div>
					</div>
					<div class="col-3">
						<div class="project-url">
							<a href="<?php the_permalink(); ?>">
								<svg width="20" height="20" viewBox="0 0 20 20" fill="none"
									xmlns="http://www.w3.org/2000/svg">
									<path
										d="M18.75 6.73047V1.73047H13.75M1.25 19.2305L18.75 1.73047L1.25 19.2305Z"
										stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
								</svg>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	endwhile;
	wp_reset_postdata();
	?>
</div>
