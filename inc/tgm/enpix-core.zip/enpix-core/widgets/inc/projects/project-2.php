<?php
$portfolio_title = $settings['portfolio_title'] ?? '';
?>

<div class="row d-flex justify-content-between align-items-center">
	<div class="col-xl-5 text-xl-start text-center">
		<h2><?php echo esc_html( $portfolio_title ); ?></h2>
	</div>
	<?php if ( count( $project_cats ) >= 2 ) : ?>
		<div class="col-xxl-5 col-xl-7">
			<div class="portfolio-filter-buttons justify-content-center align-items-center">
				<button class="selected" data-filter="*"><?php esc_html_e( 'All', 'enpix-core' ); ?></button>
				<?php foreach ( $project_cats as $project_cat ) : ?>
					<button data-filter=".<?php echo esc_attr( $project_cat ); ?>"><?php echo esc_html( get_term_by( 'slug', $project_cat, 'project-categories' )->name ); ?></button>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endif; ?>
</div>

<div class="enpix-portfolio-grid mt-80">
	<?php
	while ( $projects->have_posts() ) :
		$projects->the_post();

		$project_cat_object_array = get_the_terms( get_the_ID(), 'project-categories' );
		$project_cats_slug        = [];
		$project_cats_name        = [];

		if ( ! empty( $project_cat_object_array ) ) {
			foreach ( $project_cat_object_array as $element ) {
				array_push( $project_cats_slug, $element->slug );
			}
		}
		?>
		<div class="portfolio-item <?php echo esc_attr( implode( ' ', $project_cats_slug ) ); ?>">
			<div class="portfolio-image relative">
				<?php the_post_thumbnail( 'enpix_630x401' ); ?>
				<div class="portfolio-hover-overlay"></div>
				<a href="<?php the_permalink(); ?>" class="portfolio-hover-link"><?php esc_html_e( 'View', 'enpix-core' ); ?></a>
			</div>
			<div class="portfolio-text mt-30">
				<?php if ( ! empty( $project_cat_object_array ) ) : ?>
					<div class="portfolio-tags">
						<?php
						foreach ( $project_cat_object_array as $element ) {
							echo '<a href=' . esc_url( home_url() ) . '/project-categories/' . esc_attr( $element->slug ) . '>' . esc_html( $element->name ) . '</a> ';
						}
						?>
					</div>
				<?php endif; ?>
				<h2 class="heading-5 mt-15"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			</div>
		</div>
		<?php
	endwhile;
	wp_reset_postdata()
	?>
</div>
