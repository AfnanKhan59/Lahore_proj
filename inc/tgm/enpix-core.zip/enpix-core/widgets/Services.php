<?php
namespace Enpix\Core;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Services extends Widget_Base {
	public function get_name() {
		return 'enpix_services';
	}

	public function get_title() {
		return esc_html__( 'Services Table', 'enpix-core' );
	}

	public function get_icon() {
		return 'bl_icon eicon-post-list';
	}

	public function get_categories() {
		return [ 'enpix' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'services',
			[
				'label' => esc_html__( 'Services Table', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'service_icon',
			[
				'label' => esc_html__( 'Service Icon', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::ICONS,
			]
		);

		$repeater->add_control(
			'service_title',
			[
				'label'       => esc_html__( 'Service Title', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'service_desc',
			[
				'label'       => esc_html__( 'Short Description', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'placeholder' => esc_html__( 'Placeholder Text', 'enpix-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'service_link',
			[
				'label'       => esc_html__( 'Service URL', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'options'     => [ 'url', 'is_external', 'nofollow' ],
			]
		);

		$this->add_control(
			'service_array',
			[
				'label'       => esc_html__( 'Enter Table Values', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'service_icon'  => [
							'value'   => 'far fa-lightbulb',
							'library' => 'fa-regular',
						],
						'service_title' => esc_html__( 'Brand Consultant', 'enpix-core' ),
						'service_desc'  => esc_html__( 'Lorem Ipsum is simply dummy text of the printing.', 'enpix-core' ),
						'service_link'  => [
							'url'               => 'https://www.example.com',
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
					],
					[
						'service_icon'  => [
							'value'   => 'far fa-lightbulb',
							'library' => 'fa-regular',
						],
						'service_title' => esc_html__( 'Brand Consultant', 'enpix-core' ),
						'service_desc'  => esc_html__( 'Lorem Ipsum is simply dummy text of the printing.', 'enpix-core' ),
						'service_link'  => [
							'url'               => 'https://www.example.com',
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
					],
					[
						'service_icon'  => [
							'value'   => 'far fa-lightbulb',
							'library' => 'fa-regular',
						],
						'service_title' => esc_html__( 'Brand Consultant', 'enpix-core' ),
						'service_desc'  => esc_html__( 'Lorem Ipsum is simply dummy text of the printing.', 'enpix-core' ),
						'service_link'  => [
							'url'               => 'https://www.example.com',
							'is_external'       => true,
							'nofollow'          => true,
							'custom_attributes' => '',
						],
					],
				],
				'title_field' => '{{{ service_title }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'icon_color',
			[
				'label' => esc_html__( 'Icon', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'icon_tabs',
		);

		$this->start_controls_tab(
			'icon_tab_normal',
			[
				'label' => esc_html__( 'Normal', 'enpix-core' ),
			]
		);

		$this->add_control(
			'icon_color_normal',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} table.idea-categories tr svg path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_tab_hover',
			[
				'label' => esc_html__( 'Hover', 'enpix-core' ),
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} table.idea-categories tr:hover svg path' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'project_title_style',
			[
				'label' => esc_html__( 'Project Title', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'project_title_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} table.idea-categories tr td p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'project_title_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} table.idea-categories tr td p',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'project_desc_style',
			[
				'label' => esc_html__( 'Project Description', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'project_desc_color',
			[
				'label'     => esc_html__( 'Color', 'enpix-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} table.idea-categories tr td p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'project_desc_typo',
				'label'    => esc_html__( 'Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} table.idea-categories tr td p',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		include 'inc/services/services.php';
	}
}
