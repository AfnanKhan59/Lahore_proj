<?php
namespace Enpix\Core;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Testimonials extends Widget_Base {
	public function get_name() {
		return 'enpix_reviews';
	}

	public function get_title() {
		return esc_html__( 'Testimonials', 'enpix-core' );
	}

	public function get_icon() {
		return 'bl_icon eicon-star';
	}

	public function get_tags() {
		return [ 'review', 'quote' ];
	}

	public function get_categories() {
		return [ 'enpix' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'review_contents',
			[
				'label' => esc_html__( 'Review Contents', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'is_icon',
			[
				'label'        => esc_html__( 'Show Icon', 'enpix-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'enpix-core' ),
				'label_off'    => esc_html__( 'Hide', 'enpix-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'is_arrows',
			[
				'label'        => esc_html__( 'Show Slider Arrows', 'enpix-core' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'enpix-core' ),
				'label_off'    => esc_html__( 'Hide', 'enpix-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'review_text',
			[
				'label' => esc_html__( 'Review Text', 'enpix-core' ),
				'type'  => \Elementor\Controls_Manager::TEXTAREA,
				'rows'  => 10,
			]
		);

		$repeater->add_control(
			'reviewer',
			[
				'label'       => esc_html__( 'Reviewer', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => esc_html__( 'Designation', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'company',
			[
				'label'       => esc_html__( 'Company/Organization', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->add_control(
			'review_repeater',
			[
				'label'       => esc_html__( 'Reviews', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'review_text' => esc_html__( '5 stars design agency! If anyone wants an example of what you can do with this theme, check out my site at artishthemes.com.', 'enpix-core' ),
						'reviewer'    => esc_html__( 'Cooper Saris', 'enpix-core' ),
						'designation' => esc_html__( 'Project Manager', 'enpix-core' ),
						'company'     => esc_html__( 'Corder', 'enpix-core' ),
					],
					[
						'review_text' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam a leo tellus. ', 'enpix-core' ),
						'reviewer'    => esc_html__( 'John Doe', 'enpix-core' ),
						'designation' => esc_html__( 'Chief Manager', 'enpix-core' ),
						'company'     => esc_html__( 'Toto', 'enpix-core' ),
					],
				],
				'title_field' => '{{{ reviewer }}}, {{{ company }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'review_body_styles',
			[
				'label' => esc_html__( 'Review Body', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'review_body_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#212833',
				'selectors' => [
					'{{WRAPPER}} .review-text p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'review_body_typography',
				'selector' => '{{WRAPPER}} .review-text p',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'reviewer_styles',
			[
				'label' => esc_html__( 'Reviewer Name', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'reviewer_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#212833',
				'selectors' => [
					'{{WRAPPER}} .review-author h3' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'reviewer_typography',
				'selector' => '{{WRAPPER}} .review-author h3',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'designation_styles',
			[
				'label' => esc_html__( 'Designation', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'designation_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#212833',
				'selectors' => [
					'{{WRAPPER}} .review-author p' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'designation_typography',
				'selector' => '{{WRAPPER}} .review-author p',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		include 'inc/reviews/review.php';
	}
}
