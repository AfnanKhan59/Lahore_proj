<?php
namespace Enpix\Core;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use WP_Query;

defined( 'ABSPATH' ) || exit();

function enpix_team_member_list() {
	$member_array = [];
	$elements     = get_posts(
		[
			'post_type'   => 'team',
			'numberposts' => -1,
		]
	);

	if ( ! empty( $elements ) ) {
		foreach ( $elements as $element ) {
			$member_array[ $element->ID ] = $element->post_title;
		}
	}

	return $member_array;
}

class Team extends Widget_Base {
	public function get_name() {
		return 'enpix_team';
	}

	public function get_title() {
		return esc_html__( 'Team Member', 'enpix-core' );
	}

	public function get_icon() {
		return 'bl_icon eicon-person';
	}

	public function get_categories() {
		return [ 'enpix' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'team_member',
			[
				'label' => esc_html__( 'Team Member', 'enpix-core' ),
			]
		);

		$this->add_control(
			'members_list',
			[
				'label'       => esc_html__( 'Select Member to Show', 'enpix-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => enpix_team_member_list(),
				'multiple'    => true,
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'member_stying',
			[
				'label' => esc_html__( 'Member Style', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'member_name',
				'label'    => esc_html__( 'Name Typography', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .member-details h2',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$member = $settings['members_list'] ?? '';
		$args   = [
			'post_type' => 'team',
			'p'         => $member,
		];

		$team_member = new WP_Query( $args );

		while ( $team_member->have_posts() ) :
			$team_member->the_post();
			$meta         = get_post_meta( get_the_ID(), 'team-meta', true );
			$social_links = $meta['team-social-icons'] ?? [];
			$designation  = $meta['member-designation'] ?? '';
			?>
		
			<div class="team-member">
				<div class="member-image">
					<?php the_post_thumbnail(); ?>
					<div class="member-social-info">
						<?php foreach ( $social_links as $social_link ) : ?>
							<a <?php echo ! empty( $social_link['social-link']['url'] ) ? 'href="' . esc_url( $social_link['social-link']['url'] ) . '"' : ''; ?> <?php echo ! empty( $social_link['social-link']['target'] ) ? 'target="' . esc_url( $social_link['social-link']['target'] ) . '"' : ''; ?>>
								<i class="<?php echo esc_attr( $social_link['social-icon'] ); ?>"></i>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
				<div class="member-details">
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<p class="text-enpix-black-600"><?php echo esc_html( $designation ); ?></p>
				</div>
			</div>
			<?php
		endwhile;
	}
}
