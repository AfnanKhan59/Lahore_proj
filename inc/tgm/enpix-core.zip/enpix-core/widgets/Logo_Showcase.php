<?php
namespace Enpix\Core;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

defined( 'ABSPATH' ) || exit();


class Logo_Showcase extends Widget_Base {
	public function get_name() {
		return 'enpix_logo_showcase';
	}

	public function get_title() {
		return esc_html__( 'Logo Showcase', 'enpix-core' );
	}

	public function get_icon() {
		return 'bl_icon eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'enpix' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'logo_picking',
			[
				'label' => esc_html__( 'Logos Section', 'enpix-core' ),
			]
		);

		$this->add_control(
			'logo1',
			[
				'label'   => esc_html__( 'Logo 1', 'enpix-core' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'logo2',
			[
				'label'   => esc_html__( 'Logo 2', 'enpix-core' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'logo_showcase_style',
			[
				'label' => esc_html__( 'Logo showcase style', 'enpix-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'logo_box_border',
				'label'    => esc_html__( 'Logo box border', 'enpix-core' ),
				'selector' => '{{WRAPPER}} .companies-logo tr td',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		 <table class="companies-logo">
				<tbody>
					<tr>
						<?php if ( $settings['logo1']['url'] ) : ?>
						<td><img src="<?php echo esc_url( $settings['logo1']['url'] ); ?>" alt="enpix"></td>
							<?php
						endif;
						if ( $settings['logo2']['url'] ) :
							?>
						<td><img src="<?php echo esc_url( $settings['logo2']['url'] ); ?>" alt="enpix"></td>
						<?php endif; ?>
					</tr>
				</tbody>
			</table>
		<?php
	}
}
